<?php
require '../koneksi.php'; // Pastikan file koneksi tersedia

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_reserve = $_POST['id_reserve'];
    $metode_bayar = $_POST['metode_bayar'];
    $total_bayar = $_POST['total_bayar'];

    // Validasi reservasi
    $query = "SELECT total_biaya FROM reserve WHERE id_reserve = ? AND status = 'menunggu'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_reserve);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $total_biaya = $row['total_biaya'];

        // Validasi pembayaran
        if ($total_bayar != $total_biaya) {
            die("Jumlah pembayaran tidak sesuai.");
        }

        // Catat transaksi ke tabel `trx`
        $queryTrx = "INSERT INTO trx (id_reserve, total_bayar, metode_byr, tgl_trx) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($queryTrx);
        $stmt->bind_param("iis", $id_reserve, $total_bayar, $metode_bayar);
        $stmt->execute();

        // Perbarui status reservasi di tabel `reserve`
        $queryUpdateReserve = "UPDATE reserve SET status = 'menunggu' WHERE id_reserve = ?";
        $stmt = $conn->prepare($queryUpdateReserve);
        $stmt->bind_param("i", $id_reserve);
        $stmt->execute();

        // Redirect ke halaman sukses
        header("Location: pembayaran_sukses.php");
        exit();
    } else {
        die("Reservasi tidak valid.");
    }
} else {
    die("Akses tidak valid.");
}
?>
