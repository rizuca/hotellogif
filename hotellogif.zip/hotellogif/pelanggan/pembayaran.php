<?php
include "../koneksi.php";

$id_reserve = $_GET['id_reserve'] ?? null;
$total_biaya = $_GET['total_biaya'] ?? null;

if (!$id_reserve || !$total_biaya) {
    die("Reservasi tidak valid. Data yang diperlukan tidak ditemukan.");
}

// Query untuk memeriksa keberadaan reservasi di database
$query = $conn->prepare("SELECT * FROM reserve WHERE id_reserve = ? AND total_biaya = ?");
$query->bind_param("ii", $id_reserve, $total_biaya);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 0) {
    die("Reservasi tidak valid. Tidak ditemukan di database.");
}

// Ambil data reservasi
$reservasi = $result->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h4>Form Pembayaran</h4>
        </div>
        <div class="card-body">
            <form action="proses_pembayaran.php" method="POST">
                <input type="hidden" name="id_reserve" value="<?php echo $id_reserve; ?>">

                <div class="mb-3">
                    <label class="form-label">ID Reservasi</label>
                    <input type="text" class="form-control" value="<?php echo $id_reserve; ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Total Biaya</label>
                    <input type="text" class="form-control" value="Rp <?php echo number_format($total_biaya, 0, ',', '.'); ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Metode Pembayaran</label>
                    <select name="metode_bayar" class="form-select" required>
                        <option value="">-- Pilih Metode --</option>
                        <option value="Transfer Bank">Transfer Bank</option>
                        <option value="Kartu Kredit">Kartu Kredit</option>
                        <option value="E-Wallet">E-Wallet</option>
                        <option value="E-Wallet">Cash</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jumlah Pembayaran</label>
                    <input type="number" name="total_bayar" class="form-control" placeholder="Masukkan jumlah pembayaran" required>
                </div>

                <button type="submit" class="btn btn-success">Konfirmasi Pembayaran</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
