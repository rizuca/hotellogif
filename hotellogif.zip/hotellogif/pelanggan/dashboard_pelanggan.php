<?php
include "../koneksi.php";
session_start();

if (!isset($_SESSION['id_pengguna'])) {
    echo "<script>alert('Anda harus login terlebih dahulu!'); window.location.href = '../index.php';</script>";
    exit;
}

if (!isset($_SESSION['id_pengguna']) || $_SESSION['level'] !== 'pelanggan') {
    header("Location: ../index.php"); // Redirect jika bukan pelanggan
    exit();
}

// Ambil nama pengguna dari session atau database
$id_pengguna = $_SESSION['id_pengguna'];
$query = "SELECT nama_pengguna FROM pengguna WHERE id_pengguna = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_pengguna);
$stmt->execute();
$result = $stmt->get_result();

$nama_pengguna = ($result->num_rows > 0) ? $result->fetch_assoc()['nama_pengguna'] : "Pengguna Tidak Ditemukan";

// Proses Reservasi
if (isset($_POST['submit_reservasi'])) {
    $id_kamar = $_POST['id_kamar'];
    $tgl_in = $_POST['tgl_in'];
    $tgl_out = $_POST['tgl_out'];
    $total_biaya = $_POST['total_biaya'];

    // Periksa apakah kamar tersedia
    $query = "SELECT status FROM kamar WHERE id_kamar = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_kamar);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['status'] === 'terisi') {
        echo "<script>alert('Kamar sudah terisi!');</script>";
    } else {
        // Masukkan data reservasi dengan status "menunggu"
        $queryReserve = "INSERT INTO reserve (id_pengguna, id_kamar, tgl_in, tgl_out, total_biaya, status) VALUES (?, ?, ?, ?, ?, 'menunggu')";
        $stmt = $conn->prepare($queryReserve);
        $stmt->bind_param("iissi", $id_pengguna, $id_kamar, $tgl_in, $tgl_out, $total_biaya);
        if ($stmt->execute()) {
            echo "<script>alert('Reservasi berhasil! Silakan lanjutkan pembayaran.');</script>";
            header("Location: pelanggan_dashboard.php");
            exit();
        } else {
            echo "<script>alert('Reservasi gagal: " . $stmt->error . "');</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar">
    <div class="text-center">
        <img src="../img/cmlogo.webp" alt="Logo" class="img-fluid w-50 rounded-circle mt-3">
    </div>
    <h4 class="text-center pt-2 pb-3">Selamat Datang, <?php echo $nama_pengguna;?>  </h4>
    <ul class="nav flex-column">
        <!-- Pilihan Kamar -->
        <li class="nav-item">
            <a href="#pilihanKamar" class="nav-link active" data-target="pilihanKamar">
                <i class="fa-solid fa-bed"></i> Pilihan Kamar
            </a>
        </li>
        <!-- Reservasi Kamar -->
        <li class="nav-item">
            <a href="#reservasiKamar" class="nav-link" data-target="reservasiKamar">
                <i class="fa-solid fa-calendar-plus"></i> Reservasi Kamar
            </a>
        </li>
        <li class="nav-item">
            <a href="#pembayaran" class="nav-link" data-target="pembayaran">
                <i class="fa-solid fa-credit-card"></i> Pembayaran
            </a>
        </li>
        <a href="logout.php">
            <i class="fa-solid fa-right-from-bracket"></i> Logout
        </a>
    </ul>
</div>

<div class="content">
    <!-- Tabel Pilihan Kamar -->
    <div id="pilihanKamar" class="section active">
        <h1 class="text-center mb-4">Daftar Kamar</h1>
        <!-- Tabel Kamar Single -->
        <h3>Standard</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Kamar Ke : </th>
                    <th>No Kamar</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM kamar WHERE j_kamar = 'standard'");
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    $disabled = ($row['status'] == 'terisi') ? 'disabled' : '';
                    echo '<tr>
                            <td>' . $no++ . '</td>
                            <td>' . ucfirst($row['no_kamar']) . '</td>
                            <td>Rp ' . number_format($row['harga'], 0, ',', '.') . '/malam</td>
                            <td>' . ucfirst($row['status']) . '</td>
                            <td>
                                <a href="#reservasiKamar" class="btn btn-outline-secondary ' . $disabled . '" 
                                   onclick="setKamar(' . $row['id_kamar'] . ', \'' . $row['j_kamar'] . '\', ' . $row['harga'] . ')">Pesan</a>
                            </td>
                        </tr>';
                }
                ?>
            </tbody>
        </table>

        <!-- Tabel Kamar Double -->
        <h3>Deluxe</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Kamar Ke : </th>
                    <th>No Kamar</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM kamar WHERE j_kamar = 'deluxe'");
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    $disabled = ($row['status'] == 'terisi') ? 'disabled' : '';
                    echo '<tr>
                            <td>' . $no++ . '</td>
                            <td>' . ucfirst($row['no_kamar']) . '</td>
                            <td>Rp ' . number_format($row['harga'], 0, ',', '.') . '/malam</td>
                            <td>' . ucfirst($row['status']) . '</td>
                            <td>
                                <a href="#reservasiKamar" class="btn btn-outline-secondary ' . $disabled . '" 
                                   onclick="setKamar(' . $row['id_kamar'] . ', \'' . $row['j_kamar'] . '\', ' . $row['harga'] . ')">Pesan</a>
                            </td>
                        </tr>';
                }
                ?>
            </tbody>
        </table>

        <!-- Tabel Kamar Suite -->
        <h3>Suite</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Kamar Ke : </th>
                    <th>No Kamar</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM kamar WHERE j_kamar = 'suite'");
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    $disabled = ($row['status'] == 'terisi') ? 'disabled' : '';
                    echo '<tr>
                            <td>' . $no++ . '</td>
                            <td>' . ucfirst($row['no_kamar']) . '</td>
                            <td>Rp ' . number_format($row['harga'], 0, ',', '.') . '/malam</td>
                            <td>' . ucfirst($row['status']) . '</td>
                            <td>
                                <a href="#reservasiKamar" class="btn btn-outline-secondary ' . $disabled . '" 
                                   onclick="setKamar(' . $row['id_kamar'] . ', \'' . $row['j_kamar'] . '\', ' . $row['harga'] . ')">Pesan</a>
                            </td>
                        </tr>';
                }
                ?>
            </tbody>
        </table>

    </div>

    <!-- Form Reservasi Kamar -->
    <div id="reservasiKamar" class="section">
        <h1>Reservasi Kamar</h1>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Pelanggan</label>
                <input type="text" class="form-control" id="nama" name="nama_pengguna" required>
            </div>
            <div class="mb-3">
                <label for="kamar" class="form-label">Pilih Kamar</label>
                <input type="text" class="form-control" id="kamar" name="kamar" readonly>
                <input type="hidden" id="id_kamar" name="id_kamar" required>
            </div>
            <div class="mb-3">
                <label for="tanggal_in" class="form-label">Tanggal Check-In</label>
                <input type="date" class="form-control" id="tanggal_in" name="tgl_in" required>
            </div>
            <div class="mb-3">
                <label for="tanggal_out" class="form-label">Tanggal Check-Out</label>
                <input type="date" class="form-control" id="tanggal_out" name="tgl_out" required>
            </div>
            <div class="mb-3">
                <label for="total_biaya" class="form-label">Total Biaya</label>
                <input type="number" class="form-control" id="total_biaya" name="total_biaya" readonly>
            </div>
            <button type="submit" name="submit" class="btn btn-success">Pesan Sekarang</button>
        </form>
    </div>

    <!-- Tampilkan Reservasi yang Menunggu Pembayaran -->
<!-- Menampilkan Daftar Reservasi yang Menunggu Pembayaran -->
<div class="section" id="pembayaran">
<?php
        $result = $conn->query("SELECT r.id_reserve, k.no_kamar, r.total_biaya FROM reserve r JOIN kamar k ON r.id_kamar = k.id_kamar WHERE r.id_pengguna = $id_pengguna AND r.status = 'menunggu'");
        if ($result && $result->num_rows > 0) {
            echo '<table class="table">
                    <thead>
                        <tr>
                            <th>ID Reservasi</th>
                            <th>No Kamar</th>
                            <th>Total Biaya</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>';
                    while ($row = $result->fetch_assoc()) {
                        $id_reserve = $row['id_reserve'];
                        $total_biaya = $row['total_biaya'];
                        echo '<tr>
                                <td>' . $id_reserve . '</td>
                                <td>' . $row['no_kamar'] . '</td>
                                <td>Rp ' . number_format($total_biaya, 0, ',', '.') . '</td>
                                <td>
                                    <a href="pembayaran.php?id_reserve=' . $id_reserve . '&total_biaya=' . $total_biaya . '" 
                                       class="btn btn-primary">Bayar</a>
                                </td>
                              </tr>';
                    }
                    
            echo '</tbody></table>';
        } else {
            echo '<p class="text-center">Tidak ada reservasi yang menunggu pembayaran.</p>';
        }
        ?>
</div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var pembayaranButtons = document.querySelectorAll('.btn-pembayaran');

    pembayaranButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var idReserve = button.getAttribute('data-id_reserve');
            var totalBiaya = button.getAttribute('data-total_biaya');

            // Isi data ke dalam modal
            document.getElementById('modal_hidden_id_reserve').value = idReserve;
            document.getElementById('modal_id_reserve').textContent = idReserve;
            document.getElementById('modal_total_biaya').textContent = new Intl.NumberFormat('id-ID').format(totalBiaya);
            document.getElementById('modal_total_bayar_input').value = totalBiaya;
        });
    });
});
</script>
</div>
<script>
// Menambahkan event listener untuk setiap link di sidebar
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        // Menghentikan aksi default link
        e.preventDefault();
        
        // Menghapus kelas 'active' dari semua bagian dan link
        document.querySelectorAll('.nav-link').forEach(item => item.classList.remove('active'));
        document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
        
        // Menambahkan kelas 'active' pada link yang diklik dan konten terkait
        this.classList.add('active');
        
        // Mengaktifkan bagian konten yang sesuai dengan href link
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.classList.add('active');
        }
    });
});

// Fungsi untuk mengisi form reservasi dengan data kamar yang dipilih
function setKamar(id_kamar, j_kamar, harga) {
    // Mengisi form dengan data kamar yang dipilih
    document.getElementById('kamar').value = j_kamar;
    document.getElementById('id_kamar').value = id_kamar;
    document.getElementById('total_biaya').value = harga;

    // Secara otomatis arahkan ke halaman reservasi
    document.querySelector('a[href="#reservasiKamar"]').click();
}

// Menambahkan event listener untuk menghitung total biaya berdasarkan tanggal
document.getElementById('tanggal_out').addEventListener('change', function() {
    const checkIn = new Date(document.getElementById('tanggal_in').value);
    const checkOut = new Date(this.value);
    const hargaKamar = document.getElementById('total_biaya').value;

    if (checkOut > checkIn) {
        const oneDay = 24 * 60 * 60 * 1000;
        const diffDays = Math.round((checkOut - checkIn) / oneDay);

        const total = diffDays * hargaKamar;
        document.getElementById('total_biaya').value = total;
    } else {
        alert('Tanggal check-out harus lebih besar dari tanggal check-in.');
    }
});
</script>

<?php
// Proses data jika form disubmit
if (isset($_POST['submit'])) {
    $id_pengguna = $_SESSION['id_pengguna'];
    $nama_pengguna = $_POST['nama_pengguna'];
    $id_kamar = $_POST['id_kamar'];
    $tgl_in = $_POST['tgl_in'];
    $tgl_out = $_POST['tgl_out'];
    $total_biaya = $_POST['total_biaya'];

    // Cek status kamar
    $result = $conn->query("SELECT status FROM kamar WHERE id_kamar = $id_kamar");
    $row = $result->fetch_assoc();
    if ($row['status'] == 'terisi') {
        echo "<script>alert('Kamar sudah terisi!');</script>";
    } else {
        // Simpan ke tabel reserve
        $stmt = $conn->prepare("INSERT INTO reserve (id_pengguna, id_kamar, tgl_in, tgl_out, total_biaya, status) VALUES (?, ?, ?, ?, ?, 'menunggu')");
        $stmt->bind_param("iissi", $id_pengguna, $id_kamar, $tgl_in, $tgl_out, $total_biaya);
        if ($stmt->execute()) {
            // Update status kamar menjadi 'terisi'
            $updateKamar = $conn->prepare("UPDATE kamar SET status = 'terisi' WHERE id_kamar = ?");
            $updateKamar->bind_param("i", $id_kamar);
            $updateKamar->execute();
            
            // Tandai reservasi sukses
            $_SESSION['reservasi_sukses'] = true;
            echo "<script>alert('Reservasi berhasil!');</script>";
        } else {
            echo "<script>alert('Reservasi gagal: " . $stmt->error . "');</script>";
        }
    }
}
?>
<!-- Bootstrap JS Bundle -->
 <!-- Link CSS Bootstrap -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Script jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Script Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

<script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
