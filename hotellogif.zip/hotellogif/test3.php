<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_pengguna = $_POST['nama_pengguna'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $email = $_POST['email'];
    $level = 'pelanggan'; // Default untuk pelanggan

    // Query untuk menyimpan data ke database
    $query = "INSERT INTO pengguna (nama_pengguna, username, password, tanggal_lahir, email, level) 
              VALUES ('$nama_pengguna', '$username', '$password', '$tanggal_lahir', '$email', '$level')";

    if (mysqli_query($conn, $query)) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Registrasi berhasil!',
                        text: 'Silakan login.',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#3085d6',
                        allowOutsideClick: false, // Mencegah notifikasi ditutup dengan klik di luar modal
                        allowEscapeKey: false    // Mencegah notifikasi ditutup dengan tombol Esc
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location = 'login.php';
                        }
                    });
                });
              </script>";
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Terjadi kesalahan saat registrasi.',
                        confirmButtonText: 'OK',
                        allowOutsideClick: false,
                        allowEscapeKey: false
                    });
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Popup Register Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        .modal-content {
            border-radius: 20px;
            padding: 30px;
        }
        .modal-header {
            border-bottom: none;
            text-align: center;
            justify-content: center;
            margin-top: -30px;
        }
        .modal-header h5 {
            font-size: 1.8rem;
            font-weight: bold;
        }
        .form-control {
            border-radius: 10px;
        }
        .text-muted {
            font-size: 0.9rem;
        }
        .or-divider {
            text-align: center;
            margin: 20px 0;
            font-size: 1rem;
            font-weight: bold;
            color: #6c757d;
            position: relative;
        }
        .or-divider::before,
        .or-divider::after {
            content: '';
            position: absolute;
            width: 45%;
            height: 1px;
            background-color: #ddd;
            top: 50%;
            transform: translateY(-50%);
        }
        .or-divider::before {
            left: 0;
        }
        .or-divider::after {
            right: 0;
        }
        .btn-google {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 25px;
            color: #333;
            font-weight: bold;
        }
        .btn-google img {
            width: 20px;
            margin-right: 10px;
        }
        .small-link {
            color: #007bff;
            text-decoration: none;
        }
        .small-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container text-center mt-5">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registerModal">Open Register Popup</button>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                <div class="row">
                        <div class="col-10">
                            <h5 class="modal-title mt-4 ms-5" id="loginModalLabel">Register</h5>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn-close ms-5 mt-2" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="nama_pengguna" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama_pengguna" name="nama_pengguna" required>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-custom w-100 btn-warning fw-medium rounded-pill">Register</button>
                    </form>
                    <div class="or-divider">OR</div>
                    <button type="button" class="btn btn-google w-100">
                        <img src="img/google.png" alt="Google Logo">
                        Continue with Google
                    </button>
                    <div class="text-center mt-3 text-muted">
                        <p>By continuing, you agree to our <a href="#" class="small-link">Terms of Service</a> and <a href="#" class="small-link">Privacy Policy</a>.</p>
                        <p>Already a member? <a href="#" class="small-link">Log in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
