<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dining Room</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="">
    <style>
    body{
        font-family: 'Playfair Display', serif;
        background-color: #f8f9fa;
    }      
    .navbar {
    background-color: rgba(0, 0, 0, 0.8);
    transition: top 0.3s;
  }
  .navbar-brand {
    font-size: 1.75rem;
    font-weight: bold;
    color: #f5e1a4;
  }
  .navbar-nav .nav-link {
    color: #ffffff;
    font-weight: 500;
    transition: color 0.3s;
  }
  .navbar-nav .nav-link:hover {
    color: #f5e1a4;
    border-bottom: 2px solid #f5e1a4;
  }
  /* Active link effect */
  .navbar-nav .nav-link.active {
    color: #f5e1a4;
    border-bottom: 2px solid #f5e1a4;
  }
  /* Offcanvas styling */
  .offcanvas-nav {
    background-color: rgba(0, 0, 0, 0.9);
    color: #f5e1a4;
  } 
.dining{
    background-color:#fac400;
}
.dining:hover{
    background-color: #e3b305;
}
.lead{
     margin-top:-5px;
    font-size:16px;
}
.text-left{
    margin-left:px;
    font-size:14px;
}
    </style>
</head>
<body?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Celestial Manor</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
                    <li class="nav-item"><a class="nav-link active" href="dining.php">Dining</a></li>
                    <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
                    <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Offcanvas Navbar -->
    <div class="offcanvas offcanvas-start offcanvas-nav" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Celestial Manor</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
                <li class="nav-item"><a class="nav-link active" href="dining.php">Dining</a></li>
                <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
                <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </div>
    </div>
    
    <br><br><br>

    <!-- Carousel --> 
     <div class="container mt-3">
    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner rounded">
    <div class="carousel-item active">
      <img src="img/d1.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
    <div class="carousel-item">
      <img src="img/d2.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
    <div class="carousel-item">
      <img src="img/d3.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>

    <div class="container text-center mt-5">
        <h1 class="fw-medium mb-4" >Dining</h1>
            <p class="lead fs-5">
        Celestial Manor offers an exquisite dining experience that harmonizes elegance and tranquility with the vibrant pulse of Central Jakarta. Just a few minutes from the train station, various malls, and local accessory shops, our innovative bars and restaurants provide stunning city views, including iconic landmarks like Indonesia's National Monument (Monas). Indulge in our unique live kitchen concepts and private dining rooms, each offering carefully crafted dishes and premium drinks made from the freshest seasonal ingredients. On weekends, elevate your dining experience with live DJ sets and savor signature martinis and champagne from our Rooftop bar. Whether you seek serene relaxation or culinary adventure, Celestial Manor is the perfect backdrop for every occasion.</p>
    </div>

    <!-- restaurant 1-->
    <div class="container bg-white rounded mt-5">
        <div class="row">
            <div class="col mt-3 mb-2 ms-5">
                <h2 class="ms-2">Dining Room</h2>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-lg-4 ms-5">
                <img src="img/dining.jpg" alt="dining room" class="img-fluid">
            </div>
            <div class="col-lg-5">
                <p class="lead">Dining Room offers exquisite buffets showcasing authentic Indonesian specialties alongside regional Italian cuisine made with the finest locally sourced ingredients. Enjoy breakfast, lunch, or dinner amidst stunning Central Jakarta city views and our engaging live kitchen. Elevate weekends with our delightful Sunday Brunch, offering a selection of cuisines. Explore intimate semi-private and private dining rooms for special occasions.</p>
                <div class="row">
                    <div class="col-lg-7">
                        <p class="text-left fw-bold fs-5">Hours</p>
                        <p class="text-left"><span class="fw-medium">Monday – Sunday</span></p>
                        <p class="text-left">
                            <span class="fw-medium">Breakfast:</span> 6:00 a.m. to 10:30 a.m. <br>
                            <span class="fw-medium">Lunch:</span> 11:30 a.m. to 2:30 p.m. <br>
                            <span class="fw-medium">Dinner:</span> 5:30 p.m. to 10:00 p.m. <br>
                            <span class="fw-medium">Sunday brunch:</span> 12:00 p.m. to 3:00 p.m. <br>
                        </p>
                    </div>
                    <div class="col-lg-5">
                        <p class="text-left fw-bold fs-5">Menus</p>
                        <p class="text-left">
                            <a href="img/dr1.webp">Breakfast A La Carte Menu</a>
                            <a href="img/dr2.webp">Lunch A La Carte Menu</a>
                            <a href="img/dr3.webp">Beverage Menu</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <a href="diningreservation.php" class="dining btn mb-3">Reserve Now</a>
                <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward" viewBox="0 0 16 16">
                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708"/>
                </svg> +628888888</p>
                <p class="fw-bold mt-4">Dress Code</p>
                <p>Please dress in smart casual attire and avoid wearing singlets and slippers.</p>
            </div>
        </div>
    </div>
    <!-- restaurant 2-->
    <div class="container bg-white rounded mt-5">
        <div class="row">
            <div class="col mt-3 mb-2 ms-5">
                <h2 class="ms-2">The Bar</h2>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-lg-4 ms-5">
                <img src="img/bar.png" alt="dining room" class="img-fluid rounded">
            </div>
            <div class="col-lg-5">
                <p class="lead">Discover an oasis of elegance and sophistication at The Celestial Bar, nestled within the opulent surroundings of our luxury hotel. This exclusive bar offers a refined atmosphere where guests can unwind and enjoy an extensive selection of premium beverages. With its sleek, contemporary design, The Celestial Bar features plush seating arrangements, ambient lighting, and a stunning marble counter that serves as a centerpiece. Guests are invited to savor expertly crafted cocktails, fine wines, and a curated selection of international spirits. The bar also offers a variety of gourmet appetizers and light bites, perfect for pairing with your favorite drink. Whether you're relaxing after a day of exploration or meeting with friends for an evening out, The Celestial Bar provides the ideal setting.</p>
                <div class="row">
                    <div class="col-lg-7">
                        <p class="text-left fw-bold fs-5">Hours</p>
                        <p class="text-left"><span class="fw-medium">Friday – Sunday</span> <br> 4:00 p.m - 12.00 a.m </p>
                    </div>
                    <div class="col-lg-5">
                        <p class="text-left fw-bold fs-5">Menus</p>
                        <p class="text-left">
                            <a href="img/bm.png">Bar Menus</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <a href="diningreservation.php" class="dining btn mb-3">Reserve Now</a>
                <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward" viewBox="0 0 16 16">
                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708"/>
                </svg> +628888888</p>
                <p class="fw-bold mt-4">Dress Code</p>
                <p>Please dress in smart casual attire and avoid wearing singlets and slippers.</p>
            </div>
        </div>
    </div>
    <!-- restaurant 3-->
    <div class="container bg-white rounded my-5">
        <div class="row">
            <div class="col mt-3 mb-2 ms-5">
                <h2 class="ms-2">In Room Dining</h2>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-lg-4 ms-5">
                <img src="img/inroom.jpg" alt="dining room" class="img-fluid rounded">
            </div>
            <div class="col-lg-5">
                <p class="lead">Savor a delectable local and Western cuisine in the privacy of your room with our 24-hour in-room dining service at Celestial Manor. Our culinary experts have created a menu to suit your taste, whether you are a busy traveler or a couple seeking a romantic evening in. Enjoy signature dishes, snacks, and sweets while taking in stunning city views.</p>
                <div class="row">
                    <div class="col-lg-7">
                        <p class="text-left fw-bold fs-5">Hours</p>
                        <p class="text-left"><span class="fw-medium">24 Hours, Daily </span> <br></p>
                    </div>
                    <div class="col-lg-5">
                        <p class="text-left fw-bold fs-5">Menus</p>
                        <p class="text-left">
                            <a href="img/irm.jpg">Food Menu</a> <br>
                            <a href="img/irm2.jpg">Drink Menu</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2">
                <a href="diningreservation.php" class="dining btn mb-3">Call Now</a>
                <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward" viewBox="0 0 16 16">
                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877zm10.762.135a.5.5 0 0 1 .708 0l2.5 2.5a.5.5 0 0 1 0 .708l-2.5 2.5a.5.5 0 0 1-.708-.708L14.293 4H9.5a.5.5 0 0 1 0-1h4.793l-1.647-1.646a.5.5 0 0 1 0-.708"/>
                </svg> +628888888</p>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <!-- script -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>