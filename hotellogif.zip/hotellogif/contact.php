<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Celestial Manor</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
   <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      font-family: 'Playfair Display', serif;
    }

    .navbar {
      background-color: rgba(0, 0, 0, 0.8);
      transition: top 0.3s;
    }

    .navbar-brand {
      font-size: 1.75rem;
      font-weight: bold;
      color: #f5e1a4;
    }

    .navbar-nav .nav-link {
      color: #ffffff;
      font-weight: 500;
      transition: color 0.3s;
    }

    .navbar-nav .nav-link:hover {
      color: #f5e1a4;
      border-bottom: 2px solid #f5e1a4;
    }

    .navbar-nav .nav-link.active {
      color: #f5e1a4;
      border-bottom: 2px solid #f5e1a4;
    }

    .offcanvas {
      background-color: rgba(0, 0, 0, 0.9);
      color: #f5e1a4;
    }

    .offcanvas .nav-link {
      color: #f5e1a4;
    }

    .offcanvas .nav-link:hover {
      color: #ffffff;
    }
    footer {
  position: relative;
  width: 100%;
  bottom: 0;
}

  </style>
</head>
<body>
    <!-- header -->
    <header class="header">
       <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Celestial Manor</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse d-none d-lg-flex" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
          <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
          <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
          <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
          <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Offcanvas Navbar -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
        <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
        <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>
    </header>
    <!-- header -->

    <!-- section title -->
    <section class="wrapper-content tentang" id="home">
        <div class="container-fluid">
            <div class="row" id="content-title">
                <div class="col-md-12 text-center">
                    <h2>Kontak</h2>
                </div>
            </div>
        </div>
    </section>
    <!-- section title -->

    <!-- content -->
    <div class="container kontak">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="wrapper">

                    <div class="row">
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                  <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                  <p>
                                    <span>Alamat :</span> Celestial Manor, Jl Marwins No 5, Kota Jakarta
                                  </p>
                                </div>
                              </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                  <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                  <p>
                                    <span>Phone :</span>
                                    <a href="#">+6284455667788</a>
                                  </p>
                                </div>
                              </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                  <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                  <p>
                                    <span>Email:</span>
                                    <a href="mailto:info@celestialmanor.com">info@celestialmanor.com</a>
                                  </p>
                                </div>
                              </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                  <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                  <p>
                                    <span>Website</span>
                                    <a href="#">https://celestialmanor.com</a>
                                  </p>
                                </div>
                              </div>
                        </div>
                    </div>

                    <div class="row no-gutters mb-5 mt-5">
                        <div class="col-md-7">
                            <div class="contact-wrap w-100 p-md-5 p-4">
                                <h3>Hubungi Kami</h3>
                                <div class="mb-4"> Silahkan hubungi kami jika anda tertarik dengan pengalaman menginap di Celestial Manor. </div>
                                <form id="contactForm" name="contactForm" class="contactForm" novalidate="novalidate">
                                    <div class="row">
                                        <div class="col-md-6 mb-2 mt-2">
                                            <div class="form-group">
                                                <label class="label" for="name">Nama</label>
                                                <input type="text" class="form-control" name="name" id="name" placeholder="Nama">
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-2 mt-2">
                                            <div class="form-group">
                                                <label class="label" for="email">Email</label>
                                                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-2 mt-2">
                                            <div class="form-group">
                                                <label class="label" for="subject">Subjek</label>
                                                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subjek">
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-2 mt-2">
                                            <div class="form-group">
                                                <label class="label" for="#">Pesan</label>
                                                <textarea name="message" class="form-control" cols="30" rows="4" placeholder="Pesan..." spellcheck="false"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mb-2 mt-2">
                                            <div class="form-group">
                                                <button class="btn_home view_more_btn">
                                                    Kirim Pesan <i class="fa fa-envelope"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-5 d-flex align-items-strecth">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15865.205554032125!2d106.8489626!3d-6.2239336!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3853c398dd5%3A0x1fe542123a54c34c!2sLinimuda%20Inspirasi%20Negeri!5e0!3m2!1sen!2sid!4v1709566710488!5m2!1sen!2sid" width="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div><br>
    <!-- content -->

    <!-- Footer-->
    <footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- ==== ANIMATE ON SCROLL JS CDN -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- ==== GSAP CDN ==== -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.8.0/gsap.min.js"></script>

    <!-- ==== SCRIPT.JS ==== -->
    <script src="./js/script.js" defer></script>
</body>
</html>
