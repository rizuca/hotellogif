<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Room Layout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .room-card {
      align-items: flex-start;
    }
    .room-card img {
      width: 100%;
      height: auto;
      object-fit: cover;
    }
    @media (max-width: 576px) { /* Responsivitas untuk perangkat mobile */
      .room-card {
        display: flex;
        flex-direction: row; /* Tata letak horizontal: gambar di kiri, teks di kanan */
        gap: 10px;
      }
      .room-card img {
        max-width: 40%; /* Gambar di sisi kiri */
        height: auto;
      }
      .room-info {
        flex: 1; /* Teks memenuhi sisa ruang */
      }
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
      <!-- Room 1 -->
      <div class="col">
        <div class="card room-card">
          <img src="https://via.placeholder.com/300" alt="1 King Bed With Monas View" class="img-fluid">
          <div class="card-body room-info">
            <h5 class="card-title">1 King Bed With Monas View</h5>
            <p class="card-text">Unwind within this 57 square meter room, with one king bed, a spacious work desk, and modern furnishings. The room offers a signature view of Jakarta.</p>
          </div>
        </div>
      </div>
      <!-- Room 2 -->
      <div class="col">
        <div class="card room-card">
          <img src="https://via.placeholder.com/300" alt="Park Suite King" class="img-fluid">
          <div class="card-body room-info">
            <h5 class="card-title">Park Suite King</h5>
            <p class="card-text">Pamper yourself in this spacious 87 square meter luxurious suite. The suite includes one king bed, separate bedroom, living room, and dining room areas.</p>
          </div>
        </div>
      </div>
      <!-- Room 3 -->
      <div class="col">
        <div class="card room-card">
          <img src="https://via.placeholder.com/300" alt="Park Suite Deluxe Monas View" class="img-fluid my-auto">
          <div class="card-body room-info">
            <h5 class="card-title">Park Suite Deluxe Monas View</h5>
            <p class="card-text">Unwind in a room that offers 127 square meters, with luxurious features including a rain shower, deep soaking marble bath, and floor-to-ceiling windows.</p>
          </div>
        </div>
      </div>
      <!-- Room 4 -->
      <div class="col">
        <div class="card room-card">
          <img src="https://via.placeholder.com/300" alt="Diplomat Suite" class="img-fluid">
          <div class="card-body room-info">
            <h5 class="card-title">Diplomat Suite</h5>
            <p class="card-text">This lavish and elegant suite offers 228 square meters, equipped with one king bed, a living room, private gym, kitchen, and a work desk.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
