<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Experiences</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* General body styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--c-white);
            margin: 0;
            padding: 0;
            color: #333;
        }

        /* Section styling */
        .fasilitas {
            background-color: var(--c-white);
            padding: 20px 90px;
            
        }

        .fasilitas h1 {
            text-align: center;
            font-size: 36px;
            color: var(--lg-heading);
            margin-bottom: 40px;
            padding: 10px 20px;
            background-color: var(--primary-color);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        /* Row styling */
        .fasilitas .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-bottom: 40px;
            gap: 20px;
            padding: 0 20px;
        }

        /* Column styling */
        .fasilitas .col-md-6 {
            flex: 0 0 48%;
            margin-bottom: 20px;
            position: relative;
            transition: transform 0.3s ease-in-out;
            padding: 10px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background-color: #ffffff85;
            overflow: hidden;
        }

        .fasilitas .col-md-6:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .fasilitas .col-md-6 img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        .fasilitas .col-md-6 img:hover {
            transform: scale(1.05);
        }

        /* Text content styling */
        .fasilitas h2 {
            font-size: 28px;
            color: var(--lg-heading);
            margin-top: 20px;
        }

        .fasilitas p {
            font-size: 16px;
            line-height: 1.6;
            color: var(--text-content);
            margin-bottom: 20px;
        }

        /* Media query for responsiveness */
        @media (max-width: 768px) {
            .fasilitas .col-md-6 {
                flex: 0 0 100%;
            }
        }

        /* Button styling */
        .btn {
            display: inline-block;
            padding: 12px 20px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            transition: background-color 0.3s;
            border: none;
            text-align: center;
        }

        .btn:hover {
            background-color: var(--btn-hover-color);
        }

        /* Footer styling */
        footer {
            background-color: #f5e1a4; /* Updated footer color */
            color: white;
            text-align: center;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: 50px;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.1);
        }

        footer .footer {
            margin-top: 30px;
            font-size: 14px;
        }

        /* CSS Variables */
        :root {
            --primary-color: #f5e1a4;
            --link-color: #506690;
            --btn-hover-color: rgba(58, 57, 5, 0.644);
            --lg-heading: #161c2d;
            --text-content: #869ab8;
            --fixed-header-height: 7rem;
            --c-white: #fff;
            --c-black: #000;
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.8);
            transition: top 0.3s;
        }

        .navbar-brand {
            font-size: 1.75rem;
            font-weight: bold;
            color: #f5e1a4;
        }

        .navbar-nav .nav-link {
            color: #ffffff;
            font-weight: 500;
            transition: color 0.3s;
        }

        .navbar-nav .nav-link:hover {
            color: #f5e1a4;
            border-bottom: 2px solid #f5e1a4;
        }

        .navbar-nav .nav-link.active {
            color: #f5e1a4;
            border-bottom: 2px solid #f5e1a4;
        }

        .offcanvas {
            background-color: rgba(0, 0, 0, 0.9);
            color: #f5e1a4;
        }

        .offcanvas .nav-link {
            color: #f5e1a4;
        }

        .offcanvas .nav-link:hover {
            color: #ffffff;
        }
    </style>
</head>
<body>
 <!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Celestial Manor</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse d-none d-lg-flex" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
          <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
          <li class="nav-item"><a class="nav-link active" href="exp.php">Experiences</a></li>
          <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Offcanvas Navbar -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
        <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
        <li class="nav-item"><a class="nav-link active" href="exp.php">Experiences</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>    
    

  <!-- section beranda -->
        <div class="grid-item-2">
          <div class="team_img_wrapper">
            <img src="./img/fasilitas/0.jpg" alt="team-img" style="width: 100%; height: auto; object-fit: cover;" />
          </div>
        </div>
      </div>
    </div>
</section>

<!-- section beranda -->
  
    <div class="fasilitas">
        <h1>Experiences Luxury Hotel</h1> <!-- Updated title -->
        <p class="intro-text">Nestled in a picturesque location, Celestial Manor offers a luxurious retreat where elegance and serenity come together in perfect harmony. Immerse yourself in timeless beauty and classic charm, just minutes away from the train station, shopping malls, and local accessory shops. Each of our guest rooms combines comfort with style, complemented by top-notch service and world-class amenities. Experience tranquility at The SPA, indulge in culinary delights at our variety of bars and restaurants, and don't miss out on the stunning beaches we offer. Our hotel provides an elegant setting for both celebrations and corporate events, with facilities tailored to suit every occasion. Welcome to Celestial Manor.</p>
        
        <!-- Facilities section -->
        <div class="row">
            <div class="col-md-6">
                <h2>Infinity Pool</h2>
                <a href="./img/fasilitas/1.jpg" target="_blank"><img src="./img/fasilitas/1.jpg" alt="Infinity Pool"></a>
                <p>Enjoy a special moment swimming in our stunning infinity pool. With a design that blends luxury and beauty, you can dive in while taking in the spectacular city views.</p>
            </div>
            <div class="col-md-6">
                <h2>High-End Fitness Center</h2>
                <a href="./img/fasilitas/2.jpg" target="_blank"><img src="./img/fasilitas/2.jpg" alt="Fitness Center"></a>
                <p>Stay healthy and fit at our state-of-the-art fitness center, equipped with modern equipment and full facilities. We offer training programs tailored to your health needs.</p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h2>Exclusive Restaurant and Cafe</h2>
                <a href="./img/fasilitas/3.jpg" target="_blank"><img src="./img/fasilitas/3.jpg" alt="Restaurant and Cafe"></a>
                <p>Indulge in delicious meals at our exclusive restaurant and cafe. With a cozy ambiance and a variety of menus, each meal will be an unforgettable experience.</p>
            </div>
            <div class="col-md-6">
                <h2>Beautiful Gardens and Green Spaces</h2>
                <a href="./img/fasilitas/4.jpg" target="_blank"><img src="./img/fasilitas/4.jpg" alt="Garden and Green Spaces"></a>
                <p>Relax in the beautiful gardens surrounded by green spaces. This tranquil oasis in the middle of the bustling city is perfect for unwinding after a long day.</p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h2>24/7 Security with CCTV Monitoring</h2>
                <a href="./img/fasilitas/5.jpg" target="_blank"><img src="./img/fasilitas/5.jpg" alt="Security System"></a>
                <p>With advanced 24/7 security and CCTV monitoring, we ensure that every corner of our property is safely protected, giving you peace of mind throughout your stay.</p>
            </div>
            <div class="col-md-6">
                <a href="#" class="btn">Explore More Facilities</a>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</body>
</html>
