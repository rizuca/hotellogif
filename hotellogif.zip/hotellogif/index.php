<?php 
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM pengguna WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION['id_pengguna'] = $user['id_pengguna'];
        $_SESSION['nama_pengguna'] = $user['nama_pengguna'];
        $_SESSION['level'] = $user['level']; // Menyimpan level ke session

        // Redirect berdasarkan level
        if ($user['level'] === 'resepsionis') {
            header("Location: resepsionis/d_resepsionis.php");
        } elseif ($user['level'] === 'pelanggan') {
            header("Location: pelanggan/dashboard_pelanggan.php");
        } elseif ($user['level'] === 'admin') {
            header("Location: admin/dashboard.php");
        }
        exit;
    } else {
        echo "<script>alert('Username atau password salah!');</script>";
    }
}

// Proses Register
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $nama_pengguna = mysqli_real_escape_string($conn, $_POST['nama_pengguna']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Menyimpan password tanpa hashing
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $email = $_POST['email'];
    $level = 'pelanggan';

    // Pastikan username dan email belum terdaftar
    $checkQuery = "SELECT * FROM pengguna WHERE username = ? OR email = ?";
    $stmtCheck = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmtCheck, 'ss', $username, $email);
    mysqli_stmt_execute($stmtCheck);
    $resultCheck = mysqli_stmt_get_result($stmtCheck);

    if (mysqli_num_rows($resultCheck) > 0) {
        echo "<script>alert('Username atau email sudah terdaftar!');</script>";
    } else {
        $query = "INSERT INTO pengguna (nama_pengguna, username, password, tanggal_lahir, email, level) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssssss', $nama_pengguna, $username, $password, $tanggal_lahir, $email, $level);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            icon: 'success',
                            title: 'Registrasi berhasil!',
                            text: 'Silakan login.',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = '';
                            }
                        });
                    });
                  </script>";
        } else {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Terjadi kesalahan saat registrasi.',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        });
                    });
                  </script>";
        }
    }
}
?>  

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Celestial Manor</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
  .text-container {
    position: relative;
  }
  .text-container p {
    display: none;
    overflow: hidden;
  }
  .text-container p.full-text {
    display: block;
  }
  .text-container p.truncated {
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
    .card {
      border: none; /* Menghilangkan border kartu */
      border-radius: 8px;
    }
    
    /* .dining-lead {
      margin-top: -10px;
    } */
  @media (min-width: 768px) {
    .text-container p {
      display: block;
    }
    .text-container p.truncated, .text-container p.full-text {
      -webkit-line-clamp: initial;
      overflow: visible;
    }
  }
</style>

</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-md fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Celestial Manor</a>
      <button class="navbar-toggler btn-outline-warning" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
          <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
          <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
          <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Offcanvas Navbar -->
  <div class="offcanvas offcanvas-start offcanvas-nav" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Celestial Manor</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
        <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
        <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>

  <!-- Hero Section -->
  <div class="hero-section" id="hero">
    <h1 class="fs-1 fw-medium">Celestial Manor</h1>
    <p class="fs5">Experience timeless luxury and elegance in a world of unparalleled comfort and sophistication.</p>
    <button class="btn btn-lg mt-4 bg-warning" data-bs-toggle="modal" data-bs-target="#loginModal">Book Now</button>
    <!-- <a href="" class="btn btn-lg mt-4 bg-warning" data-bs-toggle="modal" data-bs-target="#loginModal">Book Now</a> -->
  </div>

<!-- About Section -->
<div class="section bg-light text-center" id="rooms">
  <div class="container">
    <h2 class="section-title fs-1 fw-bold">Classic Style Luxury Hotel</h2>
    <div class="text-container">
      <p class="lead fs-5 truncated" id="text-content"> 
        Nestled in an idyllic location, Celestial Manor offers a luxurious retreat where elegance and tranquility harmonize. Indulge in our timeless beauty and classic charm. just a few minutes from the train station, various malls and local accessories shops. Each of our guest rooms offers a blend of comfort and style, supported by first-class service and luxurious amenities. Find serenity at The SPA, or explore a world of culinary wonders at one of the several bars and restaurants, and don't forget the beautiful beaches we provide. The hotel provides an elegant backdrop for celebrations and corporate events, with facilities to suit every occasion. Welcome to Celestial Manor.
      </p>
      <button class="btn btn-outline-dark btn-sm d-lg-none" id="toggle-text">View More</button>
    </div>
  </div>
</div>

<!-- amenities -->
<div class="container text-center py-3">
  <p class="fs-2 fw-semibold text-center pb-2">Amenities</p>
  <div class="row justify-content-center">
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-wifi mb-3"></i><br> Free Wifi
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-square-parking mb-3"></i><br> Free Parking Slot
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-utensils mb-3"></i><br> On-Site Restaurant
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-bell-concierge mb-3"></i><br> Home Service
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-dumbbell mb-3"></i><br> Fitness Center
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-person-swimming mb-3"></i><br> Swimming Pool
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-spa mb-3"></i><br> Spa
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-shirt mb-3"></i><br> Laundry
    </div>
    <div class="col-lg-2 col-md-3 col-sm-4 col-6 my-4">
      <i class="fa-solid fa-2x fa-house-medical mb-3"></i><br> Medical Center
    </div>
  </div>
</div>

  <!-- rooms preview-->
  <div class="container py-3">
    <div class="text-center mb-4 fs-2 fw-semibold">Rooms & Suites</div>
  <div class="row justify-content-center">
    <!-- Card 1 -->
    <div class="col-lg-4 col-md-6 mb-4 d-flex">
      <div class="card flex-row flex-md-column align-items-center">
        <img src="img/k1.jpg" class="card-img img-fluid" alt="1 King Bed With Monas View">
        <div class="card-body">
          <h5 class="card-title fw-semibold fs-4">Standard Room</h5>
          <p class="card-text">Unwind within this 57 square meter room, with one king bed, a spacious work desk, and modern furnishings. The room offers a signature view of Jakarta.</p>
        </div>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="col-lg-4 col-md-6 mb-4 d-flex">
      <div class="card flex-row flex-md-column align-items-center">
        <img src="img/k2.jpg" class="card-img img-fluid" alt="Park Suite King">
        <div class="card-body">
          <h5 class="card-title fw-semibold fs-4">Deluxe Room</h5>
          <p class="card-text">Pamper yourself in this spacious 87 square meter luxurious suite. The suite includes one king bed, separate bedroom, living room, and dining room areas.</p>
        </div>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="col-lg-4 col-md-6 mb-4 d-flex">
      <div class="card flex-row flex-md-column align-items-center">
        <img src="img/k3.jpg" class="card-img img-fluid" alt="Park Suite Deluxe Monas View">
        <div class="card-body">
          <h5 class="card-title fw-semibold fs-4">Suites Room</h5>
          <p class="card-text">Unwind in a room that offers 127 square meters, with luxurious features including a rain shower, deep soaking marble bath, and floor-to-ceiling windows.</p>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- dining -->
<div class="container my-5">
  <p class="text-center fs-2 fw-semibold"> Our Restaurant</p>
  <div class="row">
    <div class="col-6">
      <img src="img/d1.jpg" alt="" class="img-fluid rounded">
    </div>
    <div class="col-6">
      <p class="dining-lead lead text-start mt-3">With its innovative bars and restaurants, offers a new level of luxury experiences to culinary connoisseurs. A variety of intimate and stylish drinking, dining, and entertainment venues—the majority with outdoor spaces—present unique concepts and new experiences. Whichever the venue, the focus remains on providing carefully crafted, delicious food and drinks made from the finest and freshest seasonal and organic ingredients.</p>
       <a href="dining.php" class="btn btn-warning">See The Menus</a>    
    </div>
  </div>
</div>

<!-- gallery Hotel -->
<div class="container py-5">
<p class="text-center fs-2 fw-semibold mb-4" >Our Hotel</p>
  <div class="row align-items-center">
    <!-- Kolom Gambar -->
    <div class="col-lg-6 pt-2">
      <img src="img/gym.jpg" alt="Fitness Centre" class="img-fluid custom-img">
    </div>
    <!-- Kolom Teks -->
    <div class="col-lg-6 pt-2">
      <div class="custom-card">
        <h3 class="fw-bold">FITNESS CENTRE</h3>
        <p class="lead">The Fitness Centre offers a 24-hour workout experience with stunning views. Equipped with state-of-the-art Technogym® cardio machines, free weights, and wellness programs, it’s the perfect space to maintain your fitness routine.</p>
        <p class="text-left fw-bold fs-5">Hours</p>
        <p class="text-left"><span class="fw-medium">everyday</span> <br> 24 Hours </p>
      </div>
    </div>

    <!-- Kolom Teks -->
    <div class="col-lg-6 pt-2 mt-5 ">
      <div class="custom-card">
        <h3 class="fw-bold text-end">Swimming Pool</h3>
        <p class="lead text-end">Experience the ultimate relaxation at our luxurious infinity swimming pool, designed to offer a serene escape from the everyday hustle. Surrounded by breathtaking views, the pool provides a tranquil setting for a refreshing swim or a leisurely dip.</p>
        <p class="text-left fw-bold fs-5 text-end">Hours</p>
        <p class="text-left text-end"><span class="fw-medium text-end">Monday – Sunday</span> <br> 08:00 a.m - 06.00 p.m </p>
      </div>
    </div>
        <!-- Kolom Gambar -->
        <div class="col-lg-6 pt-2 mt-5 ">
      <img src="img/kolber.jpg" alt="Fitness Centre" class="img-fluid custom-img">
    </div>

        <!-- Kolom Gambar -->
        <div class="col-lg-6 mt-5 pt-2">
      <img src="img/spa.jpg" alt="Fitness Centre" class="img-fluid custom-img">
    </div>
    <!-- Kolom Teks -->
    <div class="col-lg-6 mt-5 pt-2">
      <div class="custom-card">
        <h3 class="fw-bold">Spa</h3>
        <p class="lead">Indulge in a rejuvenating experience at our serene spa, where soothing treatments and expert therapists help you relax, unwind, and refresh your mind and body</p>
        <p class="text-left fw-bold fs-5">Hours</p>
        <p class="text-left"><span class="fw-medium">everyday</span> <br> 24 Hours </p>
      </div>
    </div>

  </div>
</div>

<!-- Modal Login -->
<div class="container text-center mt-5">
        <!-- <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button> -->
    </div>

    <!-- Modal Login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-10">
                            <h5 class="modal-title mt-4 ms-5" id="loginModalLabel">Welcome To Our Hotel</h5>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn-close ms-5" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <input type="hidden" name="login">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="text-end mb-3">
                            <a href="#" class="small-link">Forgot your password?</a>
                        </div>
                        <button type="submit" class="btn btn-warning fw-medium w-100 rounded-pill">Login</button>
                    </form>
                    <div class="or-divider">OR</div>
                    <button type="button" class="btn btn-google w-100 mb-3">
                        <img src="img/google.png" alt="Google Logo"> Continue with Google
                    </button>
                    <button type="button" class="btn btn-google w-100" style="background-color: #1877f2; color: white;">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/1/1b/Facebook_icon.svg" alt="Facebook Logo">
                        Continue with Facebook
                    </button>
                    <div class="text-center mt-3 text-muted">
                        <p>Not on Our App yet? <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#registerModal" class="small-link">Sign up</a></p>
                        <p>Are you a business? <a href="#" class="small-link">Get started here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Register -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-10">
                            <h5 class="modal-title mt-4 ms-5" id="registerModalLabel">Register</h5>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn-close ms-5" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <input type="hidden" name="register">
                        <div class="mb-3">
                            <label for="nama_pengguna" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama_pengguna" name="nama_pengguna" required>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-warning fw-medium w-100 rounded-pill">Register</button>
                    </form>
                    <div class="or-divider">OR</div>
                    <button type="button" class="btn btn-google w-100">
                        <img src="img/google.png" alt="Google Logo"> Continue with Google
                    </button>
                    <div class="text-center mt-3 text-muted">
                        <p>Already a member? <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#loginModal" class="small-link">Log in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end modal login / register -->

  <!-- Scripts -->
  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const textContent = document.getElementById('text-content');
    const toggleButton = document.getElementById('toggle-text');

    toggleButton.addEventListener('click', function () {
      if (textContent.classList.contains('truncated')) {
        textContent.classList.remove('truncated');
        textContent.classList.add('full-text');
        toggleButton.textContent = 'View Less';
      } else {
        textContent.classList.remove('full-text');
        textContent.classList.add('truncated');
        toggleButton.textContent = 'View More';
      }
    });
  });
</script>

<footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
