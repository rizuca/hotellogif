<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Celestial Manor - Rooms & Suites</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom styling */
    body {
      font-family: 'Playfair Display', serif;
      background-color: #f8f9fa;
    }
    .navbar {
      background-color: rgba(0, 0, 0, 0.8);
    }
    .navbar-brand {
      font-size: 1.75rem;
      font-weight: bold;
      color: #f5e1a4;
    }
    .navbar-brand:hover{
      font-size: 1.75rem;
      font-weight: bold;
      color: white;
    }
    .navbar-nav .nav-link {
      color: #ffffff;
      font-weight: 500;
      transition: color 0.3s, border-bottom 0.3s;
    }
    /* Hover effect */
    .navbar-nav .nav-link:hover {
      color: #f5e1a4; /* Warna emas saat hover */
      border-bottom: 2px solid #f5e1a4;
    }
    /* Active link effect */
    .navbar-nav .nav-link.active {
      color: #f5e1a4; /* Warna emas saat di halaman aktif */
      border-bottom: 2px solid #f5e1a4; /* Garis bawah pada halaman aktif */
    }
    /* Section styling */
    .section-title {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      text-align: center;
      color: #333;
    }
    /* Card styling */
    .room-card {
      border: none;
      border-radius: 10px;
      transition: transform 0.3s;
      overflow: hidden;
    }
    .room-card:hover {
      transform: scale(1.03);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }
    .room-card img {
      width: 100%;
      height: auto;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }
    .room-info {
      background-color: #ffffff;
      color: #333;
      padding: 1rem;
      text-align: left;
    }
    .room-info h5 {
      font-size: 1.5rem;
      color: #f5e1a4;
    }
    .room-info p {
      margin: 0.5rem 0;
      color: #666;
    }
    .price {
      font-size: 1.25rem;
      font-weight: bold;
      color: #333;
    }
    .btn-view {
      background-color: #f5e1a4;
      color: #000;
      font-weight: bold;
      display: block;
      width: 100%;
      margin-top: 10px;
      text-align: center;
    }
  </style>
</head>
<body>

  <!-- Rooms & Suites Section -->
  <div class="section-rooms text-center" id="room">
    <h2 class="section-title">Rooms & Suites</h2>
    <div class="container">
      <div class="row">
        <!-- Room 1 -->
        <div class="col-lg-4 col-xs-6 mb-4">
          <div class="card room-card">
            <img src="img/k1.jpg" alt="Royal Suite">
            <div class="room-info">
              <h5>Royal Suite</h5>
              <p>Experience luxury with panoramic views and elegant furnishings.</p>
              <p class="price">$450 / night</p>
              <a href="#" class="btn btn-view">View Details</a>
            </div>
          </div>
        </div>
        <!-- Room 2 -->
        <div class="col-lg-4 col-xs-6 mb-4">
          <div class="card room-card">
            <img src="img/k2.jpg" alt="Classic King">
            <div class="room-info">
              <h5>Classic King</h5>
              <p>Spacious and classic, perfect for a serene retreat. very good for family vacation</p>
              <p class="price">$320 / night</p>
              <a href="#" class="btn btn-view">View Details</a>
            </div>
          </div>
        </div>
        <!-- Room 3 -->
        <div class="col-lg-4 col-xs-6 mb-4">
          <div class="card room-card">
            <img src="img/k3.jpg" alt="Grand Twin">
            <div class="room-info">
              <h5>Grand Twin</h5>
              <p>A luxurious twin room with all the amenities for comfort. </p>
              <p class="price">$290 / night</p>
              <a href="#" class="btn btn-view">View Details</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
