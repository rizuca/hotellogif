<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Celestial Manor - Rooms & Suites</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Playfair Display', serif;
    }

    .navbar {
      background-color: rgba(0, 0, 0, 0.8);
      transition: top 0.3s;
    }

    .navbar-brand {
      font-size: 1.75rem;
      font-weight: bold;
      color: #f5e1a4;
    }

    .navbar-nav .nav-link {
      color: #ffffff;
      font-weight: 500;
      transition: color 0.3s;
    }

    .navbar-nav .nav-link:hover {
      color: #f5e1a4;
      border-bottom: 2px solid #f5e1a4;
    }

    .navbar-nav .nav-link.active {
      color: #f5e1a4;
      border-bottom: 2px solid #f5e1a4;
    }

    .offcanvas {
      background-color: rgba(0, 0, 0, 0.9);
      color: #f5e1a4;
    }

    .offcanvas .nav-link {
      color: #f5e1a4;
    }

    .offcanvas .nav-link:hover {
      color: #ffffff;
    }
    /* Section styling */
    .section-title {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      text-align: center;
      color: #333;
    }
    /* Card styling */
    .room-card {
      border: none;
      border-radius: 10px;
      transition: transform 0.3s;
      overflow: hidden;
    }
    .room-card:hover {
      transform: scale(1.03);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }
    .room-card img {
      width: 100%;
      height: auto;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }
    .room-info {
      background-color: #ffffff;
      color: #333;
      padding: 1rem;
      text-align: left;
    }
    .room-info h5 {
      font-size: 1.5rem;
      color: #f5e1a4;
    }
    .room-info p {
      margin: 0.5rem 0;
      color: #666;
    }
    .price {
      font-size: 1.25rem;
      font-weight: bold;
      color: #333;
    }
    .btn-view {
      background-color: #f5e1a4;
      color: #000;
      font-weight: bold;
      display: block;
      width: 100%;
      margin-top: 10px;
      text-align: center;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Celestial Manor</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse d-none d-lg-flex" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link active" href="rooms.php">Rooms & Suites</a></li>
          <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
          <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
          <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Offcanvas Navbar -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="rooms.php">Rooms & Suites</a></li>
        <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
        <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
        <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>

<br><br><br><br>
  <!-- Rooms & Suites Section -->
  <div class="hero"></div>
  <div class="section-rooms text-center" id="room">
    <h2 class="section-title">Rooms & Suites</h2>
    <div class="container">
      <div class="row">
        <!-- Room 1 -->
        <div class="col-md-4 mb-4">
          <div class="card room-card my-3">
            <img src="img/k1.jpg" alt="Royal Suite">
            <div class="room-info">
              <h5>Standard Room</h5>
              <p>Experience luxury with panoramic views and elegant furnishings.</p>
              <p class="price">Rp. 500k / night</p>
              <a href="#" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#modal1">View Details</a>
            </div>
          </div>
        </div>

        <!-- Room 2 -->
        <div class="col-md-4 mb-4">
          <div class="card room-card my-3">
            <img src="img/k2.jpg" alt="Classic King">
            <div class="room-info">
              <h5>Deluxe Room</h5>
              <p>Spacious and classic, perfect for a serene retreat. very good for family vacation</p>
              <p class="price">Rp. 1.000k / night</p>
              <a href="#" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#modal2">View Details</a>
            </div>
          </div>
        </div>
        <!-- Room 3 -->
        <div class="col-md-4 mb-4">
          <div class="card room-card my-3">
            <img src="img/k3.jpg" alt="Grand Twin">
            <div class="room-info">
              <h5>Suites Room</h5>
              <p>A luxurious twin room with all the amenities for comfort. </p>
              <p class="price">Rp. 1.500k / night</p>
              <a href="#" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#modal3">View Details</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>



  <!-- modal 1 -->
  <div class="modal fade" id="modal1" tabindex="-1" aria-labelledby="modal1Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="img/k1.jpg" alt="Hotel View 1"><br>
                <h5>Standard Room</h5>
              <p>Experience luxury with panoramic views and elegant furnishings.</p>
              <p class="price">Rp. 500k / night</p>
            </div>
        </div>
    </div>
  <!-- modal 2 -->
  <div class="modal fade" id="modal2" tabindex="-1" aria-labelledby="modal1Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="img/k1.jpg" alt="Hotel View 1"><br>
                <h5>Deluxe Room</h5>
              <p>Spacious and classic, perfect for a serene retreat. very good for family vacation</p>
              <p class="price">Rp. 1.000k / night</p>
            </div>
        </div>
    </div>
  <!-- modal 3 -->
  <div class="modal fade" id="modal3" tabindex="-1" aria-labelledby="modal1Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="img/k1.jpg" alt="Hotel View 1"><br>
                <h5>Suites Room</h5>
              <p>A luxurious twin room with all the amenities for comfort. </p>
              <p class="price">Rp. 1.500k / night</p>
            </div>
        </div>
    </div>


    <footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
