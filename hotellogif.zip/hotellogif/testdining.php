<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Room Layout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
@media (max-width: 768px) {
    .text-left, .text-md-start {
        text-align: center;
    }
    .fw-bold.fs-5 {
        font-size: 18px;
    }
    .lead {
        font-size: 14px;
        text-align: justify;
    }
    img.img-fluid {
        max-width: 90%;
        margin: auto;
    }
}
  </style>
</head>
<body>

<!-- restaurant 1-->
<div class="container bg-white rounded mt-5">
    <div class="row">
        <div class="col mt-3 mb-2 text-center">
            <h2 class="ms-2">Dining Room</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4 col-md-6 col-sm-12 text-center">
            <img src="img/dining.jpg" alt="dining room" class="img-fluid rounded">
        </div>
        <div class="col-lg-5 col-md-6 col-sm-12">
            <p class="lead text-center text-md-start">Dining Room offers exquisite buffets showcasing authentic Indonesian specialties alongside regional Italian cuisine made with the finest locally sourced ingredients. Enjoy breakfast, lunch, or dinner amidst stunning Central Jakarta city views and our engaging live kitchen. Elevate weekends with our delightful Sunday Brunch, offering a selection of cuisines. Explore intimate semi-private and private dining rooms for special occasions.</p>
            <div class="row">
                <div class="col-md-7 col-sm-12">
                    <p class="fw-bold fs-5">Hours</p>
                    <p>
                        <span class="fw-medium">Monday – Sunday</span><br>
                        <span class="fw-medium">Breakfast:</span> 6:00 a.m. to 10:30 a.m.<br>
                        <span class="fw-medium">Lunch:</span> 11:30 a.m. to 2:30 p.m.<br>
                        <span class="fw-medium">Dinner:</span> 5:30 p.m. to 10:00 p.m.<br>
                        <span class="fw-medium">Sunday brunch:</span> 12:00 p.m. to 3:00 p.m.<br>
                    </p>
                </div>
                <div class="col-md-5 col-sm-12">
                    <p class="fw-bold fs-5">Menus</p>
                    <p>
                        <a href="#">Breakfast A La Carte Menu</a><br>
                        <a href="#">Lunch A La Carte Menu</a><br>
                        <a href="#">Beverage Menu</a>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-12 text-center mt-3">
            <a href="diningreservation.php" class="dining btn mb-3">Reserve Now</a>
            <p>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-forward" viewBox="0 0 16 16">
                    <path d="..."/>
                </svg>
                +628888888
            </p>
            <p class="fw-bold mt-4">Dress Code</p>
            <p>Please dress in smart casual attire and avoid wearing singlets and slippers.</p>
        </div>
    </div>
</div>






<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
