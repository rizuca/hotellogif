<?php
// Database Connection
include "koneksi.php";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Room Reservation Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pengguna = $_POST['id_pengguna'];
    $id_kamar = $_POST['id_kamar'];
    $tgl_in = $_POST['tgl_in'];
    $tgl_out = $_POST['tgl_out'];

    // Fetch room price
    $result = $conn->query("SELECT harga FROM kamar WHERE id_kamar = $id_kamar AND status = 'tersedia'");
    if ($result->num_rows == 0) {
        echo "Room is unavailable or does not exist.";
        exit();
    }
    $row = $result->fetch_assoc();
    $harga_per_night = $row['harga'];

    // Calculate total cost
    $total_biaya = (strtotime($tgl_out) - strtotime($tgl_in)) / (60 * 60 * 24) * $harga_per_night;

    // Insert into reserve table
    $stmt = $conn->prepare("INSERT INTO reserve (id_pengguna, id_kamar, tgl_in, tgl_out, total_biaya, status) VALUES (?, ?, ?, ?, ?, 'digunakan')");
    $stmt->bind_param("iissi", $id_pengguna, $id_kamar, $tgl_in, $tgl_out, $total_biaya);
    if ($stmt->execute()) {
        // Update room status
        $conn->query("UPDATE kamar SET status = 'terisi' WHERE id_kamar = $id_kamar");
        echo "Reservation successful! Total cost: Rp " . $total_biaya;
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch available rooms for the dropdown
$rooms = $conn->query("SELECT * FROM kamar WHERE status = 'tersedia'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservasi Kamar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Reservasi Kamar</h1>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="id_pengguna" class="form-label">ID Pengguna</label>
                <input type="number" class="form-control" id="id_pengguna" name="id_pengguna" required>
            </div>
            <div class="mb-3">
                <label for="id_kamar" class="form-label">Pilih Kamar</label>
                <select class="form-select" id="id_kamar" name="id_kamar" required>
                    <?php while ($room = $rooms->fetch_assoc()): ?>
                        <option value="<?= $room['id_kamar'] ?>">
                            Kamar <?= ucfirst($room['j_kamar']) ?> - Rp <?= $room['harga'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="tgl_in" class="form-label">Tanggal Check-In</label>
                <input type="date" class="form-control" id="tgl_in" name="tgl_in" required>
            </div>
            <div class="mb-3">
                <label for="tgl_out" class="form-label">Tanggal Check-Out</label>
                <input type="date" class="form-control" id="tgl_out" name="tgl_out" required>
            </div>
            <button type="submit" class="btn btn-success">Pesan Sekarang</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
