<?php
session_start();
include 'koneksi.php';

// Proses Login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM pengguna WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        if ($password == $user['password']) {
            // Set session
            $_SESSION['id_pengguna'] = $user['id_pengguna'];
            $_SESSION['nama_pengguna'] = $user['nama_pengguna'];
            $_SESSION['level'] = $user['level'];

            // Redirect to the appropriate dashboard
            $redirectUrl = $user['level'] == 'admin' ? 'admin/dashboard.php' :
                ($user['level'] == 'resepsionis' ? 'resepsionis/d_resepsionis.php' :
                'pelanggan/dashboard_pelanggan.php');

            // SweetAlert + Redirect
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login berhasil!',
                    text: 'Selamat datang, " . $user['nama_pengguna'] . "!',
                    confirmButtonText: 'OK',
                    allowOutsideClick: false
                }).then(() => {
                    window.location.href = '$redirectUrl';
                });
            </script>";
            exit; // Pastikan PHP berhenti memproses setelah redirect
        } else {
            // Password salah
            echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Login gagal!',
                    text: 'Password salah.',
                    confirmButtonText: 'Coba lagi'
                });
            </script>";
        }
    } else {
        // Username tidak ditemukan
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Login gagal!',
                text: 'Username tidak ditemukan.',
                confirmButtonText: 'Coba lagi'
            });
        </script>";
    }
}
?>


// Proses Register
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $nama_pengguna = $_POST['nama_pengguna'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $email = $_POST['email'];
    $level = 'pelanggan';

    $query = "INSERT INTO pengguna (nama_pengguna, username, password, tanggal_lahir, email, level) 
              VALUES ('$nama_pengguna', '$username', '$password', '$tanggal_lahir', '$email', '$level')";

    if (mysqli_query($conn, $query)) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Registrasi berhasil!',
                        text: 'Silakan login.',
                        confirmButtonText: 'OK',
                        allowOutsideClick: false,
                        allowEscapeKey: false
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location = '';
                        }
                    });
                });
              </script>";
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Terjadi kesalahan saat registrasi.',
                        confirmButtonText: 'OK',
                        allowOutsideClick: false,
                        allowEscapeKey: false
                    });
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Register Popup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        <?php include 'styles.css'; ?>
    </style>
</head>
<body>
    <div class="container text-center mt-5">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
    </div>

    <!-- Modal Login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-10">
                            <h5 class="modal-title mt-4 ms-5" id="loginModalLabel">Welcome To Our Hotel</h5>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn-close ms-5" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <input type="hidden" name="login">
                        <div class="mb-3">
                            <label for="username" class="form-label">Email</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="text-end mb-3">
                            <a href="#" class="small-link">Forgot your password?</a>
                        </div>
                        <button type="submit" class="btn btn-warning fw-medium w-100 rounded-pill">Login</button>
                    </form>
                    <div class="or-divider">OR</div>
                    <button type="button" class="btn btn-google w-100 mb-3">
                        <img src="img/google.png" alt="Google Logo"> Continue with Google
                    </button>
                    <button type="button" class="btn btn-google w-100" style="background-color: #1877f2; color: white;">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/1/1b/Facebook_icon.svg" alt="Facebook Logo">
                        Continue with Facebook
                    </button>
                    <div class="text-center mt-3 text-muted">
                        <p>Not on Our App yet? <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#registerModal" class="small-link">Sign up</a></p>
                        <p>Are you a business? <a href="#" class="small-link">Get started here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Register -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-10">
                            <h5 class="modal-title mt-4 ms-5" id="registerModalLabel">Register</h5>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn-close ms-5" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <form method="POST" action="">
                        <input type="hidden" name="register">
                        <div class="mb-3">
                            <label for="nama_pengguna" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama_pengguna" name="nama_pengguna" required>
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-warning fw-medium w-100 rounded-pill">Register</button>
                    </form>
                    <div class="or-divider">OR</div>
                    <button type="button" class="btn btn-google w-100">
                        <img src="img/google.png" alt="Google Logo"> Continue with Google
                    </button>
                    <div class="text-center mt-3 text-muted">
                        <p>Already a member? <a href="#" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#loginModal" class="small-link">Log in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
