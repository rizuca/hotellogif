<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar bg-light">
            <div class="profile text-center mt-4">
                <img src="https://via.placeholder.com/80" class="rounded-circle mb-3" alt="Profile">
                <h5 class="mb-1">John Doe</h5>
                <p class="text-muted">Admin Hotel</p>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item"><a href="#" class="nav-link active">Dashboard</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Kelola Kamar</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Kelola Reservasi</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Kelola Pengguna</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Laporan</a></li>
                <li class="nav-item mt-4"><a href="logout.php" class="btn btn-danger btn-block">Logout</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="content w-100 p-4">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Dashboard</h2>
                <p>Saldo Hotel: <b>Rp 12.500.000</b></p>
            </div>

            <!-- Widgets -->
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Total Kamar</h5>
                        <h3>120</h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Reservasi Aktif</h5>
                        <h3>85</h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Pendapatan Bulanan</h5>
                        <h3>Rp 45.000.000</h3>
                    </div>
                </div>
            </div>

            <!-- Spending Activity -->
            <div class="card mt-4 p-4">
                <h5>Grafik Aktivitas</h5>
                <canvas id="activityChart" style="height: 200px;"></canvas>
            </div>

            <!-- Latest Transactions -->
            <div class="card mt-4 p-4">
                <h5>Transaksi Terbaru</h5>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tanggal</th>
                            <th>Deskripsi</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>10 Nov 2024</td>
                            <td>Pembayaran Reservasi</td>
                            <td>Rp 3.500.000</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>9 Nov 2024</td>
                            <td>Pembatalan Reservasi</td>
                            <td>-Rp 1.000.000</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>8 Nov 2024</td>
                            <td>Top-up Dompet</td>
                            <td>Rp 500.000</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Script untuk Chart -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['01', '02', '03', '04', '05', '06', '07'],
                datasets: [{
                    label: 'Aktivitas',
                    data: [10, 20, 15, 25, 30, 40, 35],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    </script>
</body>
</html>
