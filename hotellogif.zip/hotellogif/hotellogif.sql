-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2024 at 03:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotellogif`
--

-- --------------------------------------------------------

--
-- Table structure for table `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` int(11) NOT NULL,
  `no_kamar` varchar(11) NOT NULL,
  `j_kamar` enum('standard','deluxe','suite') NOT NULL,
  `harga` int(11) NOT NULL,
  `status` enum('tersedia','terisi') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `no_kamar`, `j_kamar`, `harga`, `status`) VALUES
(4, 'k_01', 'standard', 500000, 'tersedia'),
(5, 'd_01', 'deluxe', 1000000, 'tersedia'),
(6, 'st_01', 'suite', 1500000, 'terisi');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `email` varchar(25) NOT NULL,
  `level` enum('admin','resepsionis','pelanggan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `username`, `password`, `tanggal_lahir`, `email`, `level`) VALUES
(1, 'farzad', 'farzad', '123', NULL, '', 'pelanggan'),
(9, 'maria', 'maria', '12345', NULL, '', 'resepsionis'),
(10, 'test', 'test', 'test', NULL, '', 'pelanggan'),
(17, 'angel', 'angel', '12345', '2006-12-12', 'angel@gmail.com', 'pelanggan');

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `id_reserve` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `tgl_in` date NOT NULL,
  `tgl_out` date NOT NULL,
  `total_biaya` int(11) NOT NULL,
  `status` enum('menunggu','digunakan','selesai','dibatalkan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`id_reserve`, `id_pengguna`, `id_kamar`, `tgl_in`, `tgl_out`, `total_biaya`, `status`) VALUES
(21, 1, 6, '2024-12-01', '2024-12-10', 13500000, 'selesai'),
(22, 9, 6, '2024-12-01', '2024-12-30', 43500000, 'selesai'),
(23, 1, 4, '2024-12-01', '2024-12-02', 500000, 'selesai'),
(24, 1, 5, '2024-12-02', '2024-12-05', 3000000, 'selesai'),
(25, 1, 6, '2024-12-02', '2024-12-03', 1500000, 'selesai'),
(26, 1, 4, '2024-12-02', '2024-12-04', 1000000, 'selesai'),
(27, 1, 4, '2024-12-02', '2024-12-04', 1000000, 'selesai'),
(28, 1, 5, '2024-12-02', '2024-12-04', 2000000, 'selesai'),
(29, 1, 4, '2024-12-02', '2024-12-04', 1000000, 'selesai'),
(30, 1, 5, '2024-12-02', '2024-12-19', 17000000, 'selesai'),
(31, 17, 6, '2024-12-02', '2024-12-03', 1500000, 'selesai'),
(32, 17, 6, '2024-12-02', '2024-12-03', 1500000, 'selesai'),
(33, 17, 4, '2024-12-02', '2024-12-03', 500000, 'selesai'),
(34, 17, 5, '2024-12-02', '2024-12-04', 2000000, 'selesai'),
(35, 17, 4, '2024-12-03', '2024-12-04', 500000, 'selesai'),
(36, 17, 4, '2024-12-03', '2024-12-05', 1000000, 'selesai'),
(37, 17, 6, '2024-12-03', '2024-12-05', 3000000, 'selesai');

-- --------------------------------------------------------

--
-- Table structure for table `trx`
--

CREATE TABLE `trx` (
  `id_trx` int(11) NOT NULL,
  `id_reserve` int(11) NOT NULL,
  `total_bayar` int(11) NOT NULL,
  `metode_byr` varchar(35) NOT NULL,
  `tgl_trx` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trx`
--

INSERT INTO `trx` (`id_trx`, `id_reserve`, `total_bayar`, `metode_byr`, `tgl_trx`) VALUES
(1, 33, 500000, 'Transfer Bank', '2024-12-02 23:30:07'),
(3, 36, 1000000, 'E-Wallet', '2024-12-03 01:03:10'),
(4, 37, 3000000, 'E-Wallet', '2024-12-03 06:58:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `reserve`
--
ALTER TABLE `reserve`
  ADD PRIMARY KEY (`id_reserve`),
  ADD KEY `id_kamar` (`id_kamar`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indexes for table `trx`
--
ALTER TABLE `trx`
  ADD PRIMARY KEY (`id_trx`),
  ADD KEY `id_reserve` (`id_reserve`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `reserve`
--
ALTER TABLE `reserve`
  MODIFY `id_reserve` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `trx`
--
ALTER TABLE `trx`
  MODIFY `id_trx` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reserve`
--
ALTER TABLE `reserve`
  ADD CONSTRAINT `reserve_ibfk_1` FOREIGN KEY (`id_kamar`) REFERENCES `kamar` (`id_kamar`),
  ADD CONSTRAINT `reserve_ibfk_2` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`);

--
-- Constraints for table `trx`
--
ALTER TABLE `trx`
  ADD CONSTRAINT `trx_ibfk_1` FOREIGN KEY (`id_reserve`) REFERENCES `reserve` (`id_reserve`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
