<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri Hotel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body{
        font-family: 'Playfair Display', serif;
        background-color: #f8f9fa;
    }      
    .navbar {
    background-color: rgba(0, 0, 0, 0.8);
    transition: top 0.3s;
  }
  .navbar-brand {
    font-size: 1.75rem;
    font-weight: bold;
    color: #f5e1a4;
  }
  .navbar-nav .nav-link {
    color: #ffffff;
    font-weight: 500;
    transition: color 0.3s;
  }
  .navbar-nav .nav-link:hover {
    color: #f5e1a4;
    border-bottom: 2px solid #f5e1a4;
  }
  /* Active link effect */
  .navbar-nav .nav-link.active {
    color: #f5e1a4;
    border-bottom: 2px solid #f5e1a4;
  }
  /* Offcanvas styling */
  .offcanvas-nav {
    background-color: rgba(0, 0, 0, 0.9);
    color: #f5e1a4;
  } 
.dining{
    background-color:#fac400;
}
.dining:hover{
    background-color: #e3b305;
}
.lead{
     margin-top:-5px;
    font-size:16px;
}
.text-left{
    margin-left:px;
    font-size:14px;
}
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-md fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Celestial Manor</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
                    <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
                    <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
                    <li class="nav-item"><a class="nav-link active" href="gallery.php">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Offcanvas Navbar -->
    <div class="offcanvas offcanvas-start offcanvas-nav" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Celestial Manor</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="rooms.php">Rooms & Suites</a></li>
                <li class="nav-item"><a class="nav-link" href="dining.php">Dining</a></li>
                <li class="nav-item"><a class="nav-link" href="exp.php">Experiences</a></li>
                <li class="nav-item"><a class="nav-link active" href="gallery.php">Gallery</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            </ul>
        </div>
    </div> <br><br><br>

    <!-- Carousel --> 
    <div class="container mt-3">
    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner rounded">
    <div class="carousel-item active">
      <img src="img/d4.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
    <div class="carousel-item">
      <img src="img/d1.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
    <div class="carousel-item">
      <img src="img/gym.jpg" class="d-block w-100 img-fluid" alt="img/k.jpg">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
    
    <main class="container pb-2 mt-5">
        <div class="row g-4">
            <!-- Gambar Galeri -->
            <!-- rooms -->
             <p class="text-center fs-2 fw-semibold">Our Hotel</p><hr>
            <div class="col-md-4 gallery-item">
                <img src="img/dining.jpg" class="img-fluid" alt="Hotel View 1" data-bs-toggle="modal" data-bs-target="#r1"><br>
                <span class="fs-5">Dining Room</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/spa.jpg" class="img-fluid" alt="Hotel View 2" data-bs-toggle="modal" data-bs-target="#r2"><br>
                <span class="fs-5">Spa</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/kolber.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
                <br><span class="fs-5">Swimming Pool</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/gym.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
                <br><span class="fs-5">Fitness Centre</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/gd1.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
                <br><span class="fs-5">Conference Hall</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/gd2.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
                <br><span class="fs-5">Outdoor Restaurant</span>
            </div>
        </div>
    </main>

    <!-- Modal -->
<div class="modal fade" id="r1" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Standard Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k2.jpg" alt="" class="img-fluid"> 
        <p>standard Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r2" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Deluxe Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k3.jpg" alt="" class="img-fluid"> 
        <p>Deluxe Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r3" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Suites Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k4.jpg" alt="" class="img-fluid"> 
        <p>Suites Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
    <main class="container pb-2 mt-5">
        <div class="row g-4">

            <!-- rooms -->
             <p class="text-center fs-2 fw-semibold">Rooms & Suites</p><hr>
            <div class="col-md-4 gallery-item">
                <img src="img/k2.jpg" class="img-fluid" alt="Hotel View 1" data-bs-toggle="modal" data-bs-target="#r1"><br>
                <span class="fs-5">Standard Rooms</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k3.jpg" class="img-fluid" alt="Hotel View 2" data-bs-toggle="modal" data-bs-target="#r2">
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k4.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
            </div>
        </div>
    </main>

    <!-- Modal -->
<div class="modal fade" id="r1" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Standard Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k2.jpg" alt="" class="img-fluid"> 
        <p>standard Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r2" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Deluxe Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k3.jpg" alt="" class="img-fluid"> 
        <p>Deluxe Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r3" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Suites Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k4.jpg" alt="" class="img-fluid"> 
        <p>Suites Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>

    <main class="container pb-2 mt-5">
        <div class="row g-4">
            <!-- Gambar Galeri -->
            <!-- rooms -->
             <p class="text-center fs-2 fw-semibold">Rooms & Suites</p><hr>
            <div class="col-md-4 gallery-item">
                <img src="img/k2.jpg" class="img-fluid" alt="Hotel View 1" data-bs-toggle="modal" data-bs-target="#r1"><br>
                <span class="fs-5">Standard Rooms</span>
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k3.jpg" class="img-fluid" alt="Hotel View 2" data-bs-toggle="modal" data-bs-target="#r2">
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k4.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#r3">
            </div>
        </div>
    </main>

    <!-- Modal -->
<div class="modal fade" id="r1" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Standard Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k2.jpg" alt="" class="img-fluid"> 
        <p>standard Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r2" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Deluxe Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k3.jpg" alt="" class="img-fluid"> 
        <p>Deluxe Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="r3" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="imageModalLabel">Suites Room</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <img src="img/k4.jpg" alt="" class="img-fluid"> 
        <p>Suites Room of this hotel</p>
        <button class="btn btn-warning">order now</button>
      </div>
    </div>
  </div>
</div>

    






<footer class="bg-dark text-light py-4">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="col-lg-6 mb-3">
        <h5 class="text-uppercase">About Us</h5>
        <p>Experience luxury and comfort at Hotel Elegance, your home away from home. Located in the heart of the city, we provide world-class hospitality for a memorable stay.</p>
      </div>
      <!-- Contact Information -->
      <div class="col-lg-6 mb-3 text-center">
        <h5 class="text-uppercase">Contact Us</h5>
        <p>
          <i class="fas fa-map-marker-alt"></i> 123 Luxury Ave, Cityville<br>
          <i class="fas fa-phone-alt"></i> +1 (555) 123-4567<br>
          <i class="fas fa-envelope"></i> contact@hotelcelestialmanor.com
        </p>
        <div class="social-icons">
          <a href="#" class="text-light me-3"><i class="fab fa-facebook"></i></a>
          <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
          <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
        </div>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center">
      <p class="mb-0">&copy; 2024 Hotel Celestial Manor. All rights reserved.</p>
    </div>
  </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
