<?php
session_start();
include "../koneksi.php";

if (!isset($_SESSION['id_pengguna']) || $_SESSION['level'] !== 'resepsionis') {
    header("Location: ../index.php"); // Jika belum login atau bukan resepsionis, redirect ke login
    exit();
}
$nama_pengguna = $_SESSION['nama_pengguna'];

// Query untuk menghitung kamar tersedia
$queryKamarTersedia = "SELECT COUNT(*) AS total_tersedia FROM kamar WHERE status = 'tersedia'";
$resultKamarTersedia = $conn->query($queryKamarTersedia);
$kamarTersedia = $resultKamarTersedia->fetch_assoc()['total_tersedia'];

// Query untuk menghitung jumlah check-in hari ini
$queryCheckInHariIni = "SELECT COUNT(*) AS total_checkin FROM reserve WHERE tgl_in = CURDATE() AND status = 'digunakan'";
$resultCheckInHariIni = $conn->query($queryCheckInHariIni);
$checkInHariIni = $resultCheckInHariIni->fetch_assoc()['total_checkin'];

// Query untuk menghitung jumlah check-out hari ini
$queryCheckOutHariIni = "SELECT COUNT(*) AS total_checkout FROM reserve WHERE tgl_out = CURDATE() AND status = 'selesai'";
$resultCheckOutHariIni = $conn->query($queryCheckOutHariIni);
$checkOutHariIni = $resultCheckOutHariIni->fetch_assoc()['total_checkout'];

// Query untuk mendapatkan semua data reservasi
$queryReservasi = "SELECT reserve.id_reserve, pengguna.nama_pengguna, reserve.tgl_in, reserve.tgl_out, reserve.status, kamar.j_kamar, kamar.id_kamar
                   FROM reserve
                   JOIN pengguna ON reserve.id_pengguna = pengguna.id_pengguna
                   JOIN kamar ON reserve.id_kamar = kamar.id_kamar
                   ORDER BY reserve.tgl_in ASC";
$resultReservasi = $conn->query($queryReservasi);

// Jika ada permintaan untuk memperbarui status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_reserve = $_POST['id_reserve'];
    $new_status = $_POST['status'];
    $id_kamar = $_POST['id_kamar'];

    // Perbarui status reservasi
    $updateReserveQuery = "UPDATE reserve SET status = ? WHERE id_reserve = ?";
    $stmt = $conn->prepare($updateReserveQuery);
    $stmt->bind_param("si", $new_status, $id_reserve);
    $stmt->execute();

    // Jika statusnya selesai, ubah status kamar menjadi tersedia
    if ($new_status == 'selesai') {
        $updateKamarQuery = "UPDATE kamar SET status = 'tersedia' WHERE id_kamar = ?";
        $stmt = $conn->prepare($updateKamarQuery);
        $stmt->bind_param("i", $id_kamar);
        $stmt->execute();
    }

    // Redirect untuk menghindari pengiriman ulang form
    header("Location: d_resepsionis.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Resepsionis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            margin: 0;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #ffffff;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }
        .sidebar a {
            display: block;
            color: #ffffff;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #495057;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            width: 100%;
        }
        .menu-content {
            display: none;
        }
        .menu-content.active {
            display: block;
        }
        .card {
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border: none;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <img src="../img/cmlogo.webp" class="rounded-circle mb-2 img-fluid w-50" alt="Profile">
            <h5>Resepsionis, <?php echo "$nama_pengguna"; ?></h5>
            <p>Hotel CM</p>
        </div>
        <a href="#" onclick="showMenu('dashboard')" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="#" onclick="showMenu('konfirmasiReservasi')"><i class="fas fa-check-circle"></i> Konfirmasi Reservasi</a>
        <a href="logout.php" class="mt-auto"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <!-- Dashboard Section -->
        <div id="dashboard" class="menu-content active">
            <h2>Dashboard</h2>
            <p>Selamat datang, Resepsionis <?php echo $nama_pengguna;?> </p>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Kamar Tersedia</h5>
                        <h3><?php echo $kamarTersedia; ?></h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Check-In Hari Ini</h5>
                        <h3><?php echo $checkOutHariIni; ?></h3>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <h5>Check-Out Hari Ini</h5>
                        <h3><?php echo $checkInHariIni; ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Konfirmasi Reservasi Section -->
        <div id="konfirmasiReservasi" class="menu-content">
            <h2>Konfirmasi Reservasi</h2>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Tamu</th>
                        <th>Check-In</th>
                        <th>Check-Out</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $index = 1; while ($row = $resultReservasi->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $index++; ?></td>
                            <td><?php echo $row['nama_pengguna']; ?></td>
                            <td><?php echo date('d M Y', strtotime($row['tgl_in'])); ?></td>
                            <td><?php echo date('d M Y', strtotime($row['tgl_out'])); ?></td>
                            <td><?php echo ucfirst($row['status']); ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="id_reserve" value="<?php echo $row['id_reserve']; ?>">
                                    <input type="hidden" name="id_kamar" value="<?php echo $row['id_kamar']; ?>">
                                    <select name="status" class="form-select form-select-sm d-inline" style="width: auto;">
                                        <option value="menunggu" <?php if ($row['status'] == 'menunggu') echo 'selected'; ?>>Menunggu</option>
                                        <option value="digunakan" <?php if ($row['status'] == 'digunakan') echo 'selected'; ?>>Digunakan</option>
                                        <option value="selesai" <?php if ($row['status'] == 'selesai') echo 'selected'; ?>>Selesai</option>
                                        <option value="dibatalkan" <?php if ($row['status'] == 'dibatalkan') echo 'selected'; ?>>Dibatalkan</option>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showMenu(menuId) {
            var contents = document.getElementsByClassName('menu-content');
            for (var i = 0; i < contents.length; i++) {
                contents[i].classList.remove('active');
            }
            document.getElementById(menuId).classList.add('active');

            var links = document.querySelectorAll('.sidebar a');
            links.forEach(link => link.classList.remove('active'));
            event.target.classList.add('active');
        }
    </script>

</body>
</html>