<?php
include "../koneksi.php";

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tambahkan kamar baru
// Tambahkan kamar baru
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_kamar"])) {
    $no_kamar = $_POST['no_kamar'];
    $j_kamar = $_POST['j_kamar'];
    $harga = $_POST['harga'];
    $status = $_POST['status'];

    $sql = "INSERT INTO kamar (no_kamar, j_kamar, harga, status) VALUES ('$no_kamar', '$j_kamar', $harga, '$status')";
    if ($conn->query($sql) === TRUE) {
        $message = "Kamar berhasil ditambahkan!";
        // Redirect untuk mencegah pengulangan data
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        $message = "Error: " . $conn->error;
    }
}


// Hapus kamar
if (isset($_GET['delete'])) {
    $id_kamar = $_GET['delete'];

    // Delete related reservations first
    $sql_reserve = "DELETE FROM reserve WHERE id_kamar = $id_kamar";
    $conn->query($sql_reserve);

    // Then delete the room
    $sql_kamar = "DELETE FROM kamar WHERE id_kamar = $id_kamar";
    if ($conn->query($sql_kamar) === TRUE) {
        $message = "Kamar berhasil dihapus!";
    } else {
        $message = "Error: " . $conn->error;
    }
}


// Update kamar
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_kamar"])) {
    $id_kamar = $_POST['id_kamar'];
    $no_kamar = $_POST['no_kamar'];
    $j_kamar = $_POST['j_kamar'];
    $harga = $_POST['harga'];
    $status = $_POST['status'];

    $sql = "UPDATE kamar SET no_kamar='$no_kamar', j_kamar='$j_kamar', harga=$harga, status='$status' WHERE id_kamar=$id_kamar";
    if ($conn->query($sql) === TRUE) {
        // Store a success message in session
        session_start();
        $_SESSION['message'] = "Kamar berhasil diperbarui!";
    } else {
        // Store an error message in session
        session_start();
        $_SESSION['message'] = "Error: " . $conn->error;
    }

    // Redirect to the same page to prevent form resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Display message if available
session_start();
if (isset($_SESSION['message'])) {
    echo "<div class='alert alert-info'>" . $_SESSION['message'] . "</div>";
    unset($_SESSION['message']); // Clear the message after displaying
}


// Ambil data kamar
$result = $conn->query("SELECT * FROM kamar");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kamar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Data Kamar</h2>
    <?php if (isset($message)): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>

    <!-- Form Tambah Kamar -->
    <div class="card mb-4">
        <div class="card-header">Tambah Kamar Baru</div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label for="no_kamar" class="form-label">Nomor Kamar</label>
                    <input type="text" class="form-control" id="no_kamar" name="no_kamar" required>
                </div>
                <div class="mb-3">
                    <label for="j_kamar" class="form-label">Jenis Kamar</label>
                    <input type="text" class="form-control" id="j_kamar" name="j_kamar" required>
                </div>
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga</label>
                    <input type="number" class="form-control" id="harga" name="harga" required>
                </div>
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="tersedia">Tersedia</option>
                        <option value="terisi">Terisi</option>
                    </select>
                </div>
                <button type="submit" name="add_kamar" class="btn btn-primary">Tambah Kamar</button>
            </form>
        </div>
    </div>

    <!-- Tabel Data Kamar -->
    <table class="table table-striped my-5">
        <thead>
        <tr>
            <th>Nomor Kamar</th>
            <th>Jenis Kamar</th>
            <th>Harga</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['no_kamar'] ?></td>
                <td><?= $row['j_kamar'] ?></td>
                <td><?= $row['harga'] ?></td>
                <td><?= ucfirst($row['status']) ?></td>
                <td>
                    <!-- Tombol Edit -->
                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id_kamar'] ?>">Edit</button>
                    
                    <!-- Tombol Hapus -->
                    <a href="?delete=<?= $row['id_kamar'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus kamar ini?')">Hapus</a>
                </td>
            </tr>

            <!-- Modal Edit -->
            <div class="modal fade" id="editModal<?= $row['id_kamar'] ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Kamar</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <input type="hidden" name="id_kamar" value="<?= $row['id_kamar'] ?>">
                                <div class="mb-3">
                                    <label for="no_kamar" class="form-label">Nomor Kamar</label>
                                    <input type="text" class="form-control" name="no_kamar" value="<?= $row['no_kamar'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="j_kamar" class="form-label">Jenis Kamar</label>
                                    <input type="text" class="form-control" name="j_kamar" value="<?= $row['j_kamar'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="harga" class="form-label">Harga</label>
                                    <input type="number" class="form-control" name="harga" value="<?= $row['harga'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" name="status" required>
                                        <option value="tersedia" <?= $row['status'] == 'tersedia' ? 'selected' : '' ?>>Tersedia</option>
                                        <option value="terisi" <?= $row['status'] == 'terisi' ? 'selected' : '' ?>>Terisi</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="update_kamar" class="btn btn-primary">Simpan Perubahan</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
