<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
</head>
<body>
  <?php include '../koneksi.php'; ?>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <nav class="col-md-2 d-md-block bg-dark sidebar text-white">
        <div class="position-sticky pt-3">
          <h5 class="text-center">Admin Dashboard</h5>
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link text-white" href="#pengguna-section">
                <i class="fas fa-users"></i> Data Pengguna
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#kamar-section">
                <i class="fas fa-bed"></i> Data Kamar
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#reserve-section">
                <i class="fas fa-calendar-check"></i> Reservasi
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#trx-section">
                <i class="fas fa-receipt"></i> Transaksi
              </a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Dashboard</h1>
        </div>

        <!-- CRUD Sections -->
        <!-- Pengguna Section -->
        <section id="pengguna-section" class="mt-4">
          <h3>Data Pengguna</h3>
          <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addPenggunaModal">Tambah Pengguna</button>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Level</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $conn->query("SELECT * FROM pengguna");
              while ($row = $result->fetch_assoc()) {
                echo "<tr>
                  <td>{$row['id_pengguna']}</td>
                  <td>{$row['nama_pengguna']}</td>
                  <td>{$row['username']}</td>
                  <td>{$row['level']}</td>
                  <td>
                    <button class='btn btn-warning btn-sm'>Edit</button>
                    <a href='delete_pengguna.php?id={$row['id_pengguna']}' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>
                </tr>";
              }
              ?>
            </tbody>
          </table>
        </section>

        <!-- Kamar Section -->
        <section id="kamar-section" class="mt-4">
          <h3>Data Kamar</h3>
          <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addKamarModal">Tambah Kamar</button>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nomor Kamar</th>
                <th>Jenis</th>
                <th>Harga</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $conn->query("SELECT * FROM kamar");
              while ($row = $result->fetch_assoc()) {
                echo "<tr>
                  <td>{$row['id_kamar']}</td>
                  <td>{$row['no_kamar']}</td>
                  <td>{$row['j_kamar']}</td>
                  <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                  <td>{$row['status']}</td>
                  <td>
                    <button class='btn btn-warning btn-sm'>Edit</button>
                    <a href='delete_kamar.php?id={$row['id_kamar']}' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>
                </tr>";
              }
              ?>
            </tbody>
          </table>
        </section>

        <!-- Reservasi Section -->
        <section id="reserve-section" class="mt-4">
          <h3>Data Reservasi</h3>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Pengguna</th>
                <th>Kamar</th>
                <th>Tanggal Check-in</th>
                <th>Tanggal Check-out</th>
                <th>Status</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $conn->query("SELECT reserve.*, pengguna.nama_pengguna, kamar.no_kamar 
                                      FROM reserve 
                                      JOIN pengguna ON reserve.id_pengguna = pengguna.id_pengguna 
                                      JOIN kamar ON reserve.id_kamar = kamar.id_kamar");
              while ($row = $result->fetch_assoc()) {
                echo "<tr>
                  <td>{$row['id_reserve']}</td>
                  <td>{$row['nama_pengguna']}</td>
                  <td>{$row['no_kamar']}</td>
                  <td>{$row['tgl_in']}</td>
                  <td>{$row['tgl_out']}</td>
                  <td>{$row['status']}</td>
                  <td>
                    <button class='btn btn-warning btn-sm'>Edit</button>
                    <a href='delete_reserve.php?id={$row['id_reserve']}' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>
                </tr>";
              }
              ?>
            </tbody>
          </table>
        </section>

        <!-- Transaksi Section -->
        <section id="trx-section" class="mt-4">
          <h3>Data Transaksi</h3>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>ID Reservasi</th>
                <th>Total Bayar</th>
                <th>Metode</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $result = $conn->query("SELECT * FROM trx");
              while ($row = $result->fetch_assoc()) {
                echo "<tr>
                  <td>{$row['id_trx']}</td>
                  <td>{$row['id_reserve']}</td>
                  <td>Rp " . number_format($row['total_bayar'], 0, ',', '.') . "</td>
                  <td>{$row['metode_byr']}</td>
                  <td>{$row['tgl_trx']}</td>
                  <td>
                    <button class='btn btn-warning btn-sm'>Edit</button>
                    <a href='delete_trx.php?id={$row['id_trx']}' class='btn btn-danger btn-sm'>Hapus</a>
                  </td>
                </tr>";
              }
              ?>
            </tbody>
          </table>
        </section>

      </main>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
