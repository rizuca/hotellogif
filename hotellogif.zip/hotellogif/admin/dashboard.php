<?php
session_start();
include '../koneksi.php';

// Menghitung total pengguna
$result_pengguna = $conn->query("SELECT COUNT(*) AS total FROM pengguna");
$total_pengguna = $result_pengguna->fetch_assoc()['total'];

// Menghitung kamar tersedia dan total kamar
$result_kamar = $conn->query("SELECT 
                                (SELECT COUNT(*) FROM kamar WHERE status = 'tersedia') AS tersedia,
                                (SELECT COUNT(*) FROM kamar) AS total");
$row_kamar = $result_kamar->fetch_assoc();
$kamar_tersedia = $row_kamar['tersedia'];
$total_kamar = $row_kamar['total'];

// Menghitung pendapatan bulan ini
$result_pendapatan = $conn->query("SELECT SUM(total_bayar) AS pendapatan FROM trx WHERE MONTH(tgl_trx) = MONTH(CURRENT_DATE()) AND YEAR(tgl_trx) = YEAR(CURRENT_DATE())");
$pendapatan_bulan_ini = $result_pendapatan->fetch_assoc()['pendapatan'] ?? 0;

// Menghitung transaksi baru (hari ini)
$result_transaksi = $conn->query("SELECT COUNT(*) AS transaksi_baru FROM trx WHERE DATE(tgl_trx) = CURRENT_DATE()");
$transaksi_baru = $result_transaksi->fetch_assoc()['transaksi_baru'];

// Ambil data pendapatan per bulan
$query = "SELECT DATE_FORMAT(tgl_in, '%Y-%m') AS bulan, SUM(total_biaya) AS pendapatan 
          FROM reserve 
          WHERE status = 'diterima' 
          GROUP BY DATE_FORMAT(tgl_in, '%Y-%m')
          ORDER BY bulan";
$result = $conn->query($query);

// Inisialisasi data untuk grafik
$bulan = [];
$pendapatan = [];

while ($row = $result->fetch_assoc()) {
    $bulan[] = $row['bulan'];
    $pendapatan[] = $row['pendapatan'];
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <nav class="col-md-2 d-md-block bg-dark sidebar text-white">
        <div class="position-sticky pt-3">
          <h5 class="text-center">Admin Dashboard</h5>
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link text-white" href="#">
                <i class="fas fa-home"></i> Dashboard
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">
                <i class="fas fa-users"></i> Data Pengguna
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">
                <i class="fas fa-bed"></i> Data Kamar
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">
                <i class="fas fa-receipt"></i> Transaksi
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">
                <i class="fas fa-chart-line"></i> Laporan
              </a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h1 class="h2">Dashboard</h1>
        </div>

       <!-- Widgets -->
<div class="container mt-5">
  <div class="row">
    <div class="col-md-3">
      <div class="card bg-primary text-white">
        <div class="card-body">
          <h5>Pengguna</h5>
          <p class="mb-0">Total: <?php echo $total_pengguna; ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-success text-white">
        <div class="card-body">
          <h5>Kamar Tersedia</h5>
          <p class="mb-0"><?php echo $kamar_tersedia; ?> dari <?php echo $total_kamar; ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-warning text-white">
        <div class="card-body">
          <h5>Pendapatan Bulan Ini</h5>
          <p class="mb-0">Rp <?php echo number_format($pendapatan_bulan_ini, 0, ',', '.'); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card bg-danger text-white">
        <div class="card-body">
          <h5>Transaksi Baru</h5>
          <p class="mb-0"><?php echo $transaksi_baru; ?></p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>


<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Grafik Pendapatan Bulanan
                </div>
                <div class="card-body">
                    <canvas id="chart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Ambil data dari PHP
const labels = <?php echo json_encode($bulan); ?>;
const dataPendapatan = <?php echo json_encode($pendapatan); ?>;

// Konfigurasi Chart.js
const ctx = document.getElementById('chart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'bar', // Tipe grafik: bar, line, pie, etc.
    data: {
        labels: labels,
        datasets: [{
            label: 'Pendapatan (Rp)',
            data: dataPendapatan,
            backgroundColor: 'rgba(54, 162, 235, 0.5)', // Warna bar
            borderColor: 'rgba(54, 162, 235, 1)', // Warna border
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + new Intl.NumberFormat('id-ID').format(value); // Format angka
                    }
                }
            }
        }
    }
});
</script>

        <!-- Tabel Data -->
        <div class="row mt-4">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                Tabel Transaksi
              </div>
              <div class="card-body">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Nama Pelanggan</th>
                      <th>Kamar</th>
                      <th>Tanggal Check-in</th>
                      <th>Total Pembayaran</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>John Doe</td>
                      <td>101</td>
                      <td>2024-11-20</td>
                      <td>Rp 500.000</td>
                    </tr>
                    <!-- Data lainnya -->
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <script>
    // Grafik (Chart.js)
    const ctx = document.getElementById('chart').getContext('2d');
    const chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Pendapatan',
          data: [30000000, 45000000, 40000000, 50000000, 55000000, 75000000],
          borderColor: 'blue',
          tension: 0.1
        }]
      }
    });
  </script>

  <?php
$conn->close();
?>
</body>
</html>
