<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri Hotel</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .gallery-item img {
            transition: transform 0.3s ease-in-out;
            border: 2px solid #f0f0f0;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .gallery-item img:hover {
            transform: scale(1.1);
        }
        .modal-content {
            background-color: #000;
        }
        .modal-content img {
            width: 100%;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <header class="bg-light py-4">
        <div class="container text-center">
            <h1 class="text-primary">Galeri Hotel</h1>
        </div>
    </header>
    
    <main class="container py-5">
        <div class="row g-4">
            <!-- Gambar Galeri -->
            <div class="col-md-4 gallery-item">
                <img src="img/k2.jpg" class="img-fluid" alt="Hotel View 1" data-bs-toggle="modal" data-bs-target="#modal1">
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k3.jpg" class="img-fluid" alt="Hotel View 2" data-bs-toggle="modal" data-bs-target="#modal2">
            </div>
            <div class="col-md-4 gallery-item">
                <img src="img/k4.jpg" class="img-fluid" alt="Hotel View 3" data-bs-toggle="modal" data-bs-target="#modal3">
            </div>
        </div>
    </main>

    <!-- Modal 1 -->
    <div class="modal fade" id="modal1" tabindex="-1" aria-labelledby="modal1Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="image1.jpg" alt="Hotel View 1">
            </div>
        </div>
    </div>
    
    <!-- Modal 2 -->
    <div class="modal fade" id="modal2" tabindex="-1" aria-labelledby="modal2Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="image2.jpg" alt="Hotel View 2">
            </div>
        </div>
    </div>
    
    <!-- Modal 3 -->
    <div class="modal fade" id="modal3" tabindex="-1" aria-labelledby="modal3Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <img src="image3.jpg" alt="Hotel View 3">
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
